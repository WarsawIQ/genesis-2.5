// construct_serial.g — serialowa konstrukcja modelu Wójcika
//
// Wierne porty ŻYWYCH funkcji z pfunctions.g, tj. tych, które pgmwojcik.g
// naprawdę woła: rmake_brain, rconnect_in_layers, rconnect_columns,
// interconnect_layers, rmake_retina, rmake_readout, rconnect_retina_with_LSM,
// rconnect_readout_with_LSM.
//
// ⚠️ NIE używaj do tego functions_serial.g::connect_in_layers ani
// ::connect_collumns. Obie istnieją w pfunctions.g, obie są SERIALOWE i żadnej
// z nich pgmwojcik.g nie woła. connect_in_layers buduje inną sieć niż model:
// nie losuje niczego i wpina KAŻDĄ synapsę w Ex_channel, podczas gdy żywa
// rconnect_in_layers dzieli je progiem in_layer_prob (0,8) na Ex i Inh.
// Użycie tamtej daje kolumnę w 100 % pobudzającą — cichy błąd naukowy.
//
// Pięć świadomych odstępstw od wersji równoległej, każde wymuszone albo przez
// tryb serial, albo przez defekt w źródle:
//
//  1. Siatkówka i readout dostają w nazwie numer kolumny: retina{npos}_{i}_{j}
//     zamiast retina_{i}_{j}. W PGENESIS każdy węzeł ma osobne drzewo
//     elementów, więc kolizji nie ma; w trybie serial drzewo jest jedno i
//     wszystkie 64 kolumny nadpisałyby tę samą siatkówkę.
//  2. connect_in_layers bierze {net} jako argument. rconnect_in_layers nie
//     bierze żadnego i ma "brain" wpisane na sztywno w treść.
//  3. connect_columns używa {array_Nz} tam, gdzie rconnect_columns ma wpisane
//     16. Dziś to ta sama liczba.
//  4. rmake_retina ignoruje swój argument {cell} i kopiuje retinal_cell wpisane
//     na sztywno. Tu argument jest używany.
//  5. Synapsy powstają przez make_synapse_q, bez echa. Wyekstrahowana
//     make_synapse echuje każdą synapsę; przy ~4,4 mln synaps to zalałoby
//     dysk i zdominowało czas. rmake_synapse ma to echo zakomentowane.
//
// Geometria przy pparameters.g: pdim=8 → NodesNumber=64 kolumn po
// array_Nx*array_Ny*array_Nz = 8*8*16 = 1024 neuronów = 65 536 neuronów,
// ~4,4 mln synaps, patchdim=2.

//--------------------------------------------------------------------
// GESTOSC LACZNOSCI. 1,0 = kazdy z kazdym, czyli model odniesienia bit w bit.
//
// ⚠️ NIE MYLIC z in_layer_prob / inter_layer_prob. TAMTE decyduja, czy synapsa
// trafia w kanal POBUDZAJACY czy HAMUJACY (0,8 = 80 % pobudzajacych). TE
// decyduja, czy synapsa w ogole POWSTAJE.
//
// PO CO: przy lacznosci kazdy-z-kazdym komorka ma 63 wejscia wewnatrzwarstwowe
// i 64 miedzywarstwowe, wiec po zaplonie zbieznosc jest tak duza, ze czestosc
// ustala refrakcja (10 ms -> sufit 100 Hz), a nie sila wejscia. Stad zmierzona
// podloga 22 Hz i brak zakresu 1-10 Hz. Rzadsza lacznosc obniza zbieznosc,
// a przy okazji koszt obliczen - zmierzony jako LINIOWY w liczbie synaps.
//
// ⚠️ MUSZA byc zadeklarowane PRZED cialami funkcji, ktore ich uzywaja: SLI
// wymaga istnienia symbolu przy WCZYTYWANIU funkcji, choc wartosc czyta przy
// wywolaniu.
// Rozszerzenie (b), czesc 3: DWIE POPULACJE.
//
// pv_every = 0 wylacza rozszerzenie: routing Ex/Inh wraca do losowania na
// synapsie i model jest BIT W BIT taki, jak przed zmiana.
// pv_every = 5 daje 20 % interneuronow PV.
//
// ⚠️ Przynaleznosc jest DETERMINISTYCZNA funkcja wspolrzednych, nie losowaniem.
// Powod: `connect_in_layers` musi wiedziec, czy neuron PRESYNAPTYCZNY jest PV,
// a nie ma jak tego odczytac z elementu bez dodatkowego pola. Funkcja ze
// wspolrzednych daje te sama odpowiedz w budowniczym i w laczniku, bez
// przechowywania czegokolwiek.
//
// PO CO TOZSAMOSC, A NIE LOSOWANIE: w modelu odniesienia ten sam neuron mogl
// byc pobudzajacy dla jednego celu i hamujacy dla innego. To lamie PRAWO
// DALE'A i recenzent neurobiologiczny to zauwazy niezaleznie od osi kv3.
int pv_every = 0

// Rozszerzenie (g): HETEROGENICZNOSC STOPNIA. Warunek istnienia tezy W2.
//
// Sama gestosc daje graf Erdosa-Renyiego: kazde polaczenie z niezaleznym
// prawdopodobienstwem, wiec stopien wejsciowy ma rozklad DWUMIANOWY - waski,
// bez ogona. W2 mowi o preferencyjnej utracie wzgledem HUBOW, a w takim
// grafie hubow nie ma: topologia `hub` z lsmcd.lesion.axes usuwalaby synapsy
// "preferencyjnie" w sieci, gdzie kazdy neuron ma prawie tyle samo wejsc,
// i wyszlaby praktycznie to samo co `random`.
//
// Kazda komorka dostaje ATRAKCYJNOSC z rozkladu Pareto o wykladniku
// degree_alpha, znormalizowana do sredniej 1, wiec OCZEKIWANA gestosc sie nie
// zmienia - zmienia sie jej rozrzut. Mniejsza alfa to grubszy ogon.
//
// degree_alpha = 0 wylacza rozszerzenie i przywraca rozklad dwumianowy.
//
// ⚠️ Atrakcyjnosc dotyczy CELU, nie nadawcy: modelujemy heterogenicznosc
// stopnia WEJSCIOWEGO, bo to on decyduje, ile zbieznych wejsc trzeba do progu,
// i to jego rozklad jest w modelu Wojcika zdegenerowany do dwoch wartosci.
// Rozszerzenie (c): HETEROGENICZNOSC PARAMETROW (Deckers 2022).
//
// W modelu odniesienia wszystkie neurony sa IDENTYCZNE - powstaja przez `copy`
// z jednego prototypu. Wtedy przekraczaja prog wszystkie naraz i siec zachowuje
// sie jak jeden wielki neuron: stad ostre przejscia, ktore mierzylismy
// (cisza -> 22 Hz w 6 % zmiany przewodnosci).
//
// Rozrzut pobudliwosci powinien to WYGLADZIC, bo komorki zaczna przekraczac
// prog przy roznych poziomach wejscia. To jest hipoteza sprawdzalna, nie
// ozdoba realizmu.
//
// Zaburzamy trzy wielkosci na somie, mnoznikiem lognormalnym o wspolczynniku
// zmiennosci het_cv:
//   Gbar Na, Gbar K  — bezposrednio pobudliwosc
//   Rm               — opor wejsciowy, czyli ile depolaryzuje dany prad
//
// het_cv = 0 wylacza rozszerzenie; model jest wtedy BIT W BIT jak przedtem.
//
// ⚠️ Zaburzamy KOPIE, nie prototyp. Budowa przez `copy` jest ~1,6 ms na neuron;
// budowanie kazdego osobno przez makeneuron kosztowaloby wielokrotnie wiecej
// przy 65 536 neuronach.
float het_cv = 0.0

float degree_alpha = 0.0

float in_layer_density    = 1.0
float inter_layer_density = 1.0

//--------------------------------------------------------------------
// Losowanie z rozkladu Pareto o wykladniku alfa, znormalizowane do sredniej 1.
//
// ⚠️ POTEGOWANIE PRZEZ exp/log, NIE przez `^`. W SLI `^` to XOR bitowy:
// {0.25 ^ 2} daje 2, a {0.25 ^ 0.5} daje 0. Wyrazenie wyglada poprawnie
// i zwraca prawdopodobna liczbe. Sprawdzone 2026-08-29.

// Mnoznik lognormalny o sredniej 1 i zadanym CV.
// Lognormalny, a nie normalny: przewodnosc ujemna nie ma sensu, a rozklad
// pobudliwosci w populacjach korowych jest skosny w prawo.
//
// sigma = sqrt(log(1+CV^2)), mu = -sigma^2/2 daje srednia dokladnie 1.
// Losowanie normalne przez Boxa-Mullera, bo SLI nie ma gotowego.

function het_mnoznik(cv)
    float cv, sigma, u1, u2, z
    if (cv <= 0)
        return 1.0
    end
    sigma = {exp {0.5 * {log {log {1.0 + {cv*cv}}}}}}
    u1 = {rand 0.0001 1}
    u2 = {rand 0 1}
    z = {{exp {0.5 * {log {-2.0 * {log {u1}}}}}} * {cos {2.0 * 3.14159265 * u2}}}
    return {exp {{-0.5*sigma*sigma} + {sigma * z}}}
end

//--------------------------------------------------------------------

function pareto_1(alfa)
    float alfa
    if (alfa <= 0)
        return 1.0
    end
    // x = u^(-1/alfa), srednia alfa/(alfa-1); dzielimy przez nia, by dac 1
    return {{exp {{-1.0/alfa} * {log {rand 0.001 1}}}} * {{alfa-1.0}/alfa}}
end

//--------------------------------------------------------------------
// Czy neuron o tych wspolrzednych nalezy do populacji PV?
// Mieszanie mnoznikami wzglednie pierwszymi wobec pv_every, zeby PV nie
// ukladaly sie w plaszczyzny ani rzedy - inaczej hamowanie byloby
// przestrzennie skorelowane i siec dostalaby strukture, ktorej nie zakladamy.

function jest_pv(npos, x, y, z)
    int npos, x, y, z
    if (pv_every == 0)
        return 0
    end
    return {{{npos*31 + x*7 + y*13 + z*23} % pv_every} == 0}
end

//--------------------------------------------------------------------
// Synapsa bez echa. Poza tym identyczna z make_synapse/rmake_synapse.

function make_synapse_q(pre, post, weight, delay)
 str pre, post
 float weight, delay
 int syn_num

   addmsg {pre} {post} SPIKE
   syn_num = {getfield {post} nsynapses} - 1
   setfield {post} synapse[{syn_num}].weight {weight} \
                   synapse[{syn_num}].delay {delay}
end

//--------------------------------------------------------------------
// Port rmake_brain. Nazwa komórki: {net}{npos}_{i}_{j}_{k}, gdzie i biegnie
// po ox, j po oy, k po oz — dokładnie jak w oryginale.

function make_brain(proto, net, lx, ly, lz)
 str proto, net
 int lx, ly, lz
 int i, j, k, npos

   if (lx>0)
    array_Nx = {lx}
   end
   if (ly>0)
    array_Ny = {ly}
   end
   if (lz>0)
    array_Nz = {lz}
   end

   echo "Budowa mozgu:" {array_Nx} "x" {array_Ny} "x" {array_Nz} \
        "w" {NodesNumber} "kolumnach"

   // ⚠️ Przy pv_every > 0 make_brain kopiuje czesc komorek z /pv_cell. Jesli
   // wolajacy go nie zbudowal, siec powstaje Z DZIURAMI — brakuje co piatego
   // neuronu — a GENESIS zglasza to jako serie bledow i BUDUJE DALEJ.
   // Zdarzylo sie 2026-09-02: probnik tworzyl tylko /brain_cell.
   if (pv_every > 0 && {exists /pv_cell} == 0)
     echo "BLAD: pv_every =" {pv_every} "wymaga prototypu /pv_cell." \
          "Zawolaj makepvneuron /pv_cell przed make_brain."
     return
   end

   for (npos=1; npos<={NodesNumber}; npos={npos+1})
     for (i=1; i<={array_Nx}; i={i+1})
       for (j=1; j<={array_Ny}; j={j+1})
         for (k=1; k<={array_Nz}; k={k+1})
           // Prototyp PV jest wybierany po tozsamosci; przy pv_every = 0
           // funkcja zawsze zwraca 0 i budowa jest jak przedtem.
           if ({jest_pv {npos} {i} {j} {k}} == 1)
             copy /pv_cell {net}{npos}_{i}_{j}_{k}
           else
             copy {proto} {net}{npos}_{i}_{j}_{k}
           end
           // Heterogenicznosc: zaburzamy KOPIE. Przy het_cv = 0 mnozniki sa
           // rowne 1 i nic sie nie zmienia.
           if (het_cv > 0)
             setfield {net}{npos}_{i}_{j}_{k}/soma \
               Rm {{getfield {net}{npos}_{i}_{j}_{k}/soma Rm} * {het_mnoznik {het_cv}}}
             setfield {net}{npos}_{i}_{j}_{k}/soma/Na_squid_hh \
               Gbar {{getfield {net}{npos}_{i}_{j}_{k}/soma/Na_squid_hh Gbar} * {het_mnoznik {het_cv}}}
             setfield {net}{npos}_{i}_{j}_{k}/soma/K_squid_hh \
               Gbar {{getfield {net}{npos}_{i}_{j}_{k}/soma/K_squid_hh Gbar} * {het_mnoznik {het_cv}}}
           end

           // Atrakcyjnosc celu; przy degree_alpha = 0 zawsze 1.
           addfield {net}{npos}_{i}_{j}_{k} atrakcyjnosc
           setfield {net}{npos}_{i}_{j}_{k} atrakcyjnosc {pareto_1 {degree_alpha}}
           position {net}{npos}_{i}_{j}_{k} \
                    { {array_minx} + ({sep_x} * {i}) } \
                    { {array_miny} + ({sep_y} * {j}) } \
                    { {array_minz} + ({sep_z} * {k}) }
         end
       end
     end
   end
end

//--------------------------------------------------------------------
// Port rconnect_in_layers. Wewnątrz każdej warstwy każdy z każdym bez
// samopołączeń, cel wybierany progiem in_layer_prob: Ex_channel poniżej,
// Inh_channel powyżej. Wszystko wchodzi w dend1.

// ŁĄCZNOŚĆ ZALEŻNA OD ODLEGŁOŚCI (Voges i Perrinet 2012; patrz literatura/).
// odl_sigma w METRACH; 0 = wylaczone, czyli jednorodna gestosc jak dotad.
//
// ⚠️ OCZEKIWANA LICZBA POLACZEN ZOSTAJE BEZ ZMIAN. Profil jest normowany przez
// swoja srednia po wszystkich parach w warstwie, wiec p_eff usrednia sie do
// in_layer_density. Bez tego zmiana sigma zmienialaby jednoczesnie ROZKLAD
// i LICZBE polaczen, a gestosc jest juz znana jako dominujaca dzwignia
// (USTALENIA 1.7: 31 % przy 0,01 wobec 11 % przy 0,03). Chcemy zmierzyc, gdzie
// synapsy leza, a nie ile ich jest.
//
// ⚠️ SKALA. Separacja to sep_x = 40 um, warstwa 8x8 rozciaga sie na 396 um po
// przekatnej. Sigma z Vogesa (250 um, polowa maksimum na 240 um) daje przy tej
// geometrii stosunek prawdopodobienstw blisko/daleko rowny 3,5 — efekt realny,
// ale lagodny. Wezsze sigma zaostrza: 219x przy 120 um, 1,8e5 przy 80 um.
// Ponizej 80 um zostaje praktycznie tylko najblizsze sasiedztwo.
float odl_sigma = 0.0

// Znormalizowany profil dla pary (j,k) -> (j1,k1) w tej samej warstwie.
// Zwraca 1.0 przy odl_sigma = 0, wiec wywolanie jest bezpieczne zawsze.
function profil_odleglosci(j, k, j1, k1, srednia)
  int j, k, j1, k1
  float srednia, dx, dy, d2
  if (odl_sigma <= 0)
    return 1.0
  end
  dx = {{j - j1} * sep_x}
  dy = {{k - k1} * sep_y}
  d2 = {{dx * dx} + {dy * dy}}
  return {{exp {{-1.0 * d2} / {2.0 * odl_sigma * odl_sigma}}} / srednia}
end

// Srednia profilu po wszystkich uporzadkowanych parach roznych komorek warstwy.
// Liczona raz na budowe, nie na pare.
// ⚠️ BEZ NAWIASoW. SLI deklaruje funkcje bezargumentowe jak make_Na_squid_tab
// w channels_tab.g: `function nazwa`, bez `()`. Zapis z nawiasami daje
// `** Error - syntax error` w tej linii, a GENESIS po bledzie skryptu wpada
// w prompt i segfaultuje — czyli objaw pojawia sie DALEKO od przyczyny.
function srednia_profilu
  int a, b, a1, b1, n
  float suma, dx, dy, d2
  if (odl_sigma <= 0)
    return 1.0
  end
  suma = 0.0
  n = 0
  for (a=1; a<={array_Nx}; a={a+1})
    for (b=1; b<={array_Ny}; b={b+1})
      for (a1=1; a1<={array_Nx}; a1={a1+1})
        for (b1=1; b1<={array_Ny}; b1={b1+1})
          if ({a}!={a1} || {b}!={b1})
            dx = {{a - a1} * sep_x}
            dy = {{b - b1} * sep_y}
            d2 = {{dx * dx} + {dy * dy}}
            suma = {suma + {exp {{-1.0 * d2} / {2.0 * odl_sigma * odl_sigma}}}}
            n = {n + 1}
          end
        end
      end
    end
  end
  return {suma / n}
end


function connect_in_layers(net)
 str net
 int i, j, k, i1, j1, k1, npos
 float random_weight, random_prob, sr_profilu

   sr_profilu = {srednia_profilu}
   if (odl_sigma > 0)
     echo "LACZNOSC ZALEZNA OD ODLEGLOSCI: sigma =" {odl_sigma} \
          "m, srednia profilu =" {sr_profilu}
   end

   for (npos=1; npos<={NodesNumber}; npos={npos+1})

     for (i=1; i<={array_Nz}; i={i+1})
       for (j=1; j<={array_Nx}; j={j+1})
         for (k=1; k<={array_Ny}; k={k+1})

           i1 = {i}

           for (j1=1; j1<={array_Nx}; j1={j1+1})
             for (k1=1; k1<={array_Ny}; k1={k1+1})

               // Nawiasy sa konieczne: && wiaze silniej niz ||, wiec bez nich
               // warunek czytalby sie jako j!=j1 || (k!=k1 && rand<=gestosc)
               // i laczyl zawsze, gdy j!=j1, ignorujac gestosc.
               if (({j}!={j1}||{k}!={k1}) && {rand 0 1} <= \
                   {in_layer_density * {getfield {net}{npos}_{j1}_{k1}_{i1} atrakcyjnosc}})
                 random_weight = {rand {min_weight} {max_weight}}
                 // Przy pv_every > 0 o kanale decyduje TOZSAMOSC nadawcy,
                 // a nie losowanie: neuron PV hamuje KAZDY swoj cel.
                 if (pv_every > 0)
                   // jest_pv WPROST, nie 1-jest_pv: warunek nizej kieruje do kanalu
                   // POBUDZAJACEGO przy wartosci <= in_layer_prob, wiec neuron
                   // nie-PV musi dac 0, a PV 1. Odwrotnosc daje siec, w ktorej
                   // hamuje 80 % komorek - i jest jednorodna, wiec test na samo
                   // prawo Dale'a by tego NIE wykryl.
                   random_prob = {jest_pv {npos} {j} {k} {i}}
                 else
                   random_prob = {rand 0 1}
                 end

                 if (random_prob <= in_layer_prob)
                   make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                                  {net}{npos}_{j1}_{k1}_{i1}/dend1/Ex_channel \
                                  {random_weight} {delay}
                 else
                   make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                                  {net}{npos}_{j1}_{k1}_{i1}/dend1/Inh_channel \
                                  {random_weight} {delay}
                 end

               end

             end
           end
         end
       end
     end

   end
end

//--------------------------------------------------------------------
// Port rconnect_layers: laczy warstwe {i} z warstwa {i1} WEWNATRZ kolumny.
// Wejscie w dend1, podzial Ex/Inh progiem inter_layer_prob - tak jak w
// oryginale. Uwaga: to dend1, w odroznieniu od polaczen MIEDZYkolumnowych,
// ktore ida w dend2.

function connect_layer_pair(net, npos, i, i1)
 str net
 int npos, i, i1, j, k, j1, k1
 float random_weight, random_prob

   for (j=1; j<={array_Nx}; j={j+1})
     for (k=1; k<={array_Ny}; k={k+1})
       for (j1=1; j1<={array_Nx}; j1={j1+1})
         for (k1=1; k1<={array_Ny}; k1={k1+1})

           if ({rand 0 1} <= {inter_layer_density * {getfield {net}{npos}_{j1}_{k1}_{i1} atrakcyjnosc}})
           random_weight = {rand {min_weight} {max_weight}}
           if (pv_every > 0)
             // jest_pv WPROST, nie 1-jest_pv: warunek nizej kieruje do kanalu
                   // POBUDZAJACEGO przy wartosci <= in_layer_prob, wiec neuron
                   // nie-PV musi dac 0, a PV 1. Odwrotnosc daje siec, w ktorej
                   // hamuje 80 % komorek - i jest jednorodna, wiec test na samo
                   // prawo Dale'a by tego NIE wykryl.
                   random_prob = {jest_pv {npos} {j} {k} {i}}
           else
             random_prob = {rand 0 1}
           end

           if (random_prob <= inter_layer_prob)
             make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                            {net}{npos}_{j1}_{k1}_{i1}/dend1/Ex_channel \
                            {random_weight} {delay}
           else
             make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                            {net}{npos}_{j1}_{k1}_{i1}/dend1/Inh_channel \
                            {random_weight} {delay}
           end
           end

         end
       end
     end
   end
end

//--------------------------------------------------------------------
// Port rconnect_layers_in_columns + rmake_layers (pfunctions.g:257 i :355).
//
// ⚠️ TEGO BRAKOWALO W MOIM PIERWSZYM PORCIE. pgmwojcik.g:84 wola
// rconnect_layers_in_columns, czego nie zauwazylem przy ekstrakcji. Bez tego
// laczności warstwy 2..16 nie dostaja NICZEGO - siatkowka pobudza warstwe 1
// i na tym koniec. Pilot pokazal to wprost: aktywnych bylo dokladnie
// array_Nx*array_Ny*NodesNumber neuronow, czyli sama warstwa 1.
//
// Pary pochodza z dwoch miejsc w oryginale i razem daja ZAMKNIETY CYKL przez
// wszystkie 16 warstw:
//   rmake_layers (i = 2,5,8,11,14):  (i,i+1) oraz (i+1,i+2)
//                                    -> 2-3,3-4, 5-6,6-7, 8-9,9-10,
//                                       11-12,12-13, 14-15,15-16
//   rconnect_layers_in_columns:      1-2, 4-5, 7-8, 10-11, 13-14, 16-1
//
// Komentarz autora tlumaczy czemu 16: "16 layers - 6 in reality. 1 for LGN,
// 3 for each else 1 + 5*3 = 16" - czyli LGN plus piec warstw korowych po trzy
// podwarstwy.

function connect_layers_in_columns(net)
 str net
 int npos, i

   // ⚠️ Schemat par jest zdefiniowany DLA 16 WARSTW (LGN + 5 warstw korowych
   // po 3 podwarstwy) i nie uogolnia sie. Przy mniejszym array_Nz pary
   // wychodzace poza geometrie sa POMIJANE - to pozwala uruchomic pilota na
   // pomniejszonej sieci, ale taka siec NIE jest kolumna korowa autora.
   if ({array_Nz} != 16)
     echo "UWAGA: array_Nz =" {array_Nz} \
          "- schemat warstw jest dla 16; pary poza zakresem pominiete"
   end

   for (npos=1; npos<={NodesNumber}; npos={npos+1})

     // z rmake_layers
     for (i=2; i<=14; i={i+3})
       if ({i+1} <= {array_Nz})
         connect_layer_pair {net} {npos} {i} {i+1}
       end
       if ({i+2} <= {array_Nz})
         connect_layer_pair {net} {npos} {i+1} {i+2}
       end
     end

     // z rconnect_layers_in_columns; ostatnia para zamyka cykl
     for (i=1; i<=13; i={i+3})
       if ({i+1} <= {array_Nz})
         connect_layer_pair {net} {npos} {i} {i+1}
       end
     end
     if ({array_Nz} >= 2)
       connect_layer_pair {net} {npos} {array_Nz} 1
     end

   end
   echo "Warstwy w kolumnach polaczone."
end

//--------------------------------------------------------------------
// Port interconnect_layers. Łączy warstwę {i} kolumny {npos} z warstwą {i1}
// kolumny {npos+1}, próg inter_layer_prob, wejście w dend2 (nie dend1).

function interconnect_layers(net, i, i1, npos)
 str net
 int i, j, k, i1, j1, k1, npos
 float random_weight, random_prob

   for (j=1; j<={array_Nx}; j={j+1})
     for (k=1; k<={array_Ny}; k={k+1})
       for (j1=1; j1<={array_Nx}; j1={j1+1})
         for (k1=1; k1<={array_Ny}; k1={k1+1})

           random_weight = {rand {min_weight} {max_weight}}
           random_prob   = {rand 0 1}

           if (random_prob <= inter_layer_prob)
             make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                            {net}{npos+1}_{j1}_{k1}_{i1}/dend2/Ex_channel \
                            {random_weight} {delay}
           else
             make_synapse_q {net}{npos}_{j}_{k}_{i}/soma/spike \
                            {net}{npos+1}_{j1}_{k1}_{i1}/dend2/Inh_channel \
                            {random_weight} {delay}
           end

         end
       end
     end
   end
end

//--------------------------------------------------------------------
// Port rconnect_columns. Łańcuch: ostatnia warstwa kolumny n → pierwsza
// warstwa kolumny n+1, dla n = 1..NodesNumber-1.

function connect_columns(net)
 str net
 int npos

   for (npos=1; npos<={NodesNumber-1}; npos={npos+1})
     interconnect_layers {net} {array_Nz} 1 {npos}
   end

   echo "Kolumny polaczone."
end

//--------------------------------------------------------------------
// Port rmake_retina. Odstępstwo 1: numer kolumny w nazwie.

function make_retina(cell, ret)
 str cell, ret
 int npos, i, j

   for (npos=1; npos<={NodesNumber}; npos={npos+1})
     for (i=1; i<={patchdim}; i={i+1})
       for (j=1; j<={patchdim}; j={j+1})
         copy {cell} {ret}{npos}_{i}_{j}
         position {ret}{npos}_{i}_{j} \
                  { {array_minx} + ({sep_x} * {i}) } \
                  { {array_miny} + ({sep_y} * {j}) } \
                  { 0 }
       end
     end
   end
end

//--------------------------------------------------------------------
// Port rmake_readout. Odstępstwo 1: numer kolumny w nazwie.

function make_readout_s(cell, rea)
 str cell, rea
 int npos, i, j

   for (npos=1; npos<={NodesNumber}; npos={npos+1})
     for (i=1; i<={patchdim}; i={i+1})
       for (j=1; j<={patchdim}; j={j+1})
         copy {cell} {rea}{npos}_{i}_{j}
         position {rea}{npos}_{i}_{j} \
                  { {array_minx} + ({sep_x} * {i}) } \
                  { {array_miny} + ({sep_y} * {j}) } \
                  { 0 }
       end
     end
   end
end

//--------------------------------------------------------------------
// Port rconnect_retina_with_LSM. Siatkówka wchodzi w WARSTWĘ 1 przez dend1.

// Wejscie topograficzne o wzmocnionej wadze.
//
// ZMIANA WOBEC MODELU ODNIESIENIA, decyzja nasza 2026-08-28 (Wojcik przekazal).
// Oryginalna rconnect_retina_with_LSM dawala kazdej komorce siatkowki JEDNA
// synapse do komorki warstwy 1 o tych samych wspolrzednych. Przy patchdim = 2
// oznaczalo to 4 synapsy na kolumne 1024 neuronow: 6,2 % komorek warstwy 1
// dostawalo wejscie, po jednym. Zmierzone EPSP to 3,47 mV przy 66,5 mV do
// progu, wiec takie wejscie NIGDY nie wzbudza rezerwuaru (patrz
// model/probes/propagate_probe.g).
//
// Dwie zmiany, obie konieczne i obie z innego powodu:
//
//  POKRYCIE. Kazda komorka siatkowki obejmuje teraz BLOK warstwy 1 o rozmiarze
//  (Nx/patchdim) x (Ny/patchdim), czyli 4x4 przy geometrii domyslnej. Cztery
//  komorki siatkowki pokrywaja wtedy wszystkie 64 komorki warstwy 1, bez
//  nakladania sie. Zachowuje to retinotopie, ktora i tak wynika z pozycji
//  nadawanych przez make_retina i make_brain.
//
//  SILA - NIE ZMIENIANA. retina_weight_scale zostaje 1. Zmierzone: przy samym
//  pokryciu blokowym jedno odpalenie siatkowki zapala cala warstwe 1 (65
//  odpalen), a przy topologii 1:1 siec milczy (1 odpalenie, sama siatkowka).
//  Zaplon bierze sie stad, ze wagi sa losowe z [0,5], wiec sposrod 16 celow
//  kilka przekracza prog samodzielnie i zapala reszte przez rekurencje.
//  Parametr zostaje jako pokretlo na wypadek, gdyby realistyczny strumien z SHD
//  wymagal innego rezimu - ale domyslnie NIE odbiega od modelu odniesienia.
//
//  ⚠️ Prog pobudliwosci to ~6-8 mV nad spoczynkiem (1e-10 A daje -0,0639 bez
//  odpalenia, 2e-10 A odpala), czyli 2-3 zbiezne EPSP po 3,47 mV. NIE mylic
//  z `thresh 0` spikegena - to detektor szczytu potencjalu czynnosciowego.

float retina_weight_scale = 1.0

// ZBIEZNOSC WEJSCIA. Promien nakladania sie pol recepcyjnych: kazda komorka
// siatkowki obejmuje dodatkowo `retina_promien` komorek warstwy 1 w kazda
// strone poza swoim blokiem. 0 = zachowanie dotychczasowe, bez nakladania.
//
// ⚠️ PO CO. Przy array_Nx = patchdim wychodzi bx = by = 1 i mapowanie jest
// JEDEN DO JEDNEGO: komorka warstwy 1 ma DOKLADNIE JEDNA synapse wejsciowa
// o wadze losowej z [0, 5]. Nie ma po czym usredniac, wiec odpowiedz na bodziec
// musi byc zero-jedynkowa. Zmierzone 2026-09-05: skale wejscia od 0,02 do 0,45
// daja DOKLADNIE zero odpalen, a 0,50 daje 2 981 233 — urwisko, nie prog.
// Przy niskim Ex_channel_gmax proguja z kolei tylko te nieliczne komorki,
// ktorych jedyna waga lezy blisko maksimum: przy Ex 0,48 odpalalo 6 komorek
// z 1536 i cala aktywnosc stala w warstwie 1.
//
// ⚠️ DOMYSLNIE 0, czyli BEZ ZMIANY. Wlaczenie tego parametru zmienia model, wiec
// wyniki policzone przy 0 i przy wiekszym promieniu NIE sa porownywalne.
int retina_promien = 0


function connect_retina_with_LSM_s(ret, net)
 str ret, net
 int i, j, npos, bx, by, x, y
 int xod, xdo, yod, ydo
 float random_weight

   bx = {array_Nx / patchdim}
   by = {array_Ny / patchdim}

   // Pokrycie blokowe zaklada podzielnosc. Bez tego sprawdzenia czesc warstwy 1
   // zostalaby bez wejscia, a jedynym objawem bylyby gorsze wyniki.
   if ({bx * patchdim} != {array_Nx} || {by * patchdim} != {array_Ny})
     echo "BLAD: array_Nx =" {array_Nx} "i array_Ny =" {array_Ny} \
          "musza dzielic sie przez patchdim =" {patchdim} \
          "- inaczej czesc warstwy 1 nie dostanie wejscia"
     return
   end

   for (npos=1; npos<={NodesNumber}; npos={npos+1})
     for (i=1; i<={patchdim}; i={i+1})
       for (j=1; j<={patchdim}; j={j+1})

         // Blok rozszerzony o retina_promien w kazda strone, przyciety do
         // siatki. Przyciecie, nie zawijanie: zawijanie zszywaloby przeciwlegle
         // brzegi warstwy 1 i psuloby retinotopie, ktora jest tu jedyna
         // struktura przestrzenna.
         xod = ({i-1}*{bx}) + 1 - {retina_promien}
         xdo = ({i}*{bx}) + {retina_promien}
         yod = ({j-1}*{by}) + 1 - {retina_promien}
         ydo = ({j}*{by}) + {retina_promien}
         if ({xod} < 1)
           xod = 1
         end
         if ({yod} < 1)
           yod = 1
         end
         if ({xdo} > {array_Nx})
           xdo = {array_Nx}
         end
         if ({ydo} > {array_Ny})
           ydo = {array_Ny}
         end

         for (x={xod}; x<={xdo}; x={x+1})
           for (y={yod}; y<={ydo}; y={y+1})
             random_weight = {rand {min_weight} {max_weight}} * {retina_weight_scale}
             make_synapse_q {ret}{npos}_{i}_{j}/soma/spike \
                            {net}{npos}_{x}_{y}_{1}/dend1/Ex_channel \
                            {random_weight} {delay}
           end
         end

       end
     end
   end
end

//--------------------------------------------------------------------
// Port rconnect_readout_with_LSM. Readout czyta z WARSTWY 5.
// Uwaga: to NIE jest connect_readout_with_LSM z pfunctions.g:628 — tamta ma
// w źródle 33 otwarcia bloków na 35 "end" i czeka na rozstrzygnięcie autora.

function connect_readout_with_LSM_s(rea, net)
 str rea, net
 int i, j, npos
 float random_weight

   for (npos=1; npos<={NodesNumber}; npos={npos+1})
     for (i=1; i<={patchdim}; i={i+1})
       for (j=1; j<={patchdim}; j={j+1})
         random_weight = {rand {min_weight} {max_weight}}
         make_synapse_q {net}{npos}_{i}_{j}_{5}/soma/spike \
                        {rea}{npos}_{i}_{j}/dend1/Ex_channel \
                        {random_weight} {delay}
       end
     end
   end
end
