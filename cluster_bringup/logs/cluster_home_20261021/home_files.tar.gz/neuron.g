//genesis  -  tutorial4.g - GENESIS Version 2.0

/*======================================================================
  A sample script to create a multicompartmental neuron with synaptic
  input.  SI units are used.
  ======================================================================*/

include hhchan		// functions to create Hodgkin-Huxley channels
/* hhchan.g assigns values to the global variables EREST_ACT, ENA, EK,
   and SOMA_A.  These will be superseded by values defined below.      */

float   PI              =       3.14159

// soma parameters - chosen to be the same as in SQUID (but in SI units)
float RM = 0.33333		// specific membrane resistance (ohms m^2)
float CM = 0.01			// specific membrane capacitance (farads/m^2)
float RA = 0.3			// specific axial resistance (ohms m)
float EREST_ACT = -0.07		// resting membrane potential (volts)
float Eleak = EREST_ACT + 0.0106  // membrane leakage potential (volts)
float ENA   = 0.045               // sodium equilibrium potential
float EK    = -0.082              // potassium equilibrium potential

// cell dimensions (meters)
float soma_l = 30e-6            // cylinder equivalent to 30 micron sphere
float soma_d = 30e-6
float dend_l =100e-6		// we will add a 100 micron long dendrite
float dend_d =  2e-6		// give it a 2 micron diameter
float SOMA_A = soma_l*PI*soma_d // variable used by hhchan.g for soma area

float gmax = 5e-10		// maximum synaptic conductance (Siemen)

// Osobne przewodnosci pobudzajaca i hamujaca.
//
// ⚠️ TO NIE JEST rozszerzenie (b) ze specyfikacji. (b) to DWIE POPULACJE:
// ~80 % piramidowych i ~20 % interneuronow PV z kanalem Kv3, z routingiem
// Ex/Inh po TOZSAMOSCI neuronu presynaptycznego. Tutaj routing pozostaje
// losowy na poziomie synapsy, wiec jeden neuron nadal moze byc pobudzajacy
// dla jednego celu i hamujacy dla innego - model nie spelnia prawa Dale'a.
// To jest tylko warunek konieczny: os ei_imbalance dostaje cel do pisania.
// W modelu odniesienia oba kanaly dzielily jedno `gmax`, wiec os uszkodzenia
// ei_imbalance nie miala CZEGO zmieniac - lsmcd/lesion/axes.py emituje
// nadpisanie o nazwie Inh_channel_gmax, ktore w modelu nie istnialo i po cichu
// nie robilo nic. Domyslnie obie rowne gmax, czyli siec zdrowa jest BIT W BIT
// ta sama co przedtem.
//
// Nadpisanie dziala, bo makeneuron czyta te globalne przy WYWOLANIU, a plik
// z nadpisaniami jest wlaczany po neuron.g i przed budowa (patrz okno opisane
// w lsmcd/lesion/emit.py). Sprawdzone 2026-08-28 na przykladzie ENA.
// Potencjal odwrocenia kanalu HAMUJACEGO, ODDZIELNIE od EK.
//
// ⚠️ EK jest wspolne dla kanalu potasowego soma i dla synapsy hamujacej.
// Obnizenie go zmienia OBIE rzeczy naraz — pobudliwosc komorki i sile
// hamowania — wiec nie dalo by sie powiedziec, co zadzialalo.
//
// PO CO: przy spoczynku -0,070 V hamowanie z Ek = -0,082 ma 12 mV sily
// napedowej wobec 115 mV pobudzenia, wiec bocznikuje zamiast hiperpolaryzowac.
// Zmierzone: 32-krotne wzmocnienie przewodnosci sprowadza 55 Hz tylko do
// 31,5 Hz. Teoria sieci zbalansowanych mowi, ze hamowanie musi skalowac sie
// z pobudzeniem — sila napedowa jest tu wiezem twardszym niz przewodnosc.
float Inh_channel_Ek = EK

// STALE CZASOWE SYNAPS, w sekundach. Wartosc pierwotna 0,003 dla obu.
//
// ⚠️ PO CO NASTAWNE. Blona nie da sieci pamieci w skali bodzca: zmierzone
// 2026-09-09 (zadanie 137540), trzydziestokrotna zmiana RM nie wydluza
// odpowiedzi — ustalenie zostaje na ~20 ms, bo przewodnosc spoczynkowa jest
// zdominowana przez kanal potasowy kalamarnicy (g_K = 10,37 nS wobec wycieku
// 8,48 nS). Podnoszenie RM tylko hiperpolaryzuje komorke ku EK.
//
// Zostaja wiec synapsy. Przy tau = 3 ms przewodnosc szczytuje po 3 ms i zanika
// w kilkanascie, a okno probki ma 200 ms. Receptory NMDA w korze maja 50-100 ms
// i sa klasycznym zrodlem pamieci w rezerwuarze; zmiana nie tyka generowania
// impulsow.
float syn_tau1 = 0.003
float syn_tau2 = 0.003

float Ex_channel_gmax  = gmax
float Inh_channel_gmax = gmax

// 0 = hh_channel (jak w oryginale), 1 = tabchannel (wymagany przez hsolve).
// Ustaw PRZED wywolaniem makeneuron. Patrz channels_tab.g.
int USE_TABCHANNEL = 0

// channels_tab.g MUSI byc wciagniety wlasnie tutaj: po `include hhchan` i po
// nadpisaniu EREST_ACT/ENA/EK/SOMA_A powyzej. SLI wymaga, zeby symbol istnial
// w chwili WCZYTYWANIA ciala funkcji (inaczej "syntax error" wskazujacy na
// pierwsza linie setfield), natomiast WARTOSC czyta dopiero przy wywolaniu -
// sprawdzone 2026-08-28: nadpisanie ENA po include daje kanal z nowa wartoscia.
// Dlatego wlasnie nadpisania z tego pliku obowiazuja, tak jak zaklada komentarz
// na gorze, i dlatego channels_tab.g NIE deklaruje tych stalych sam: przy
// odwrotnej kolejnosci wlaczen cofnalby je do wartosci z hhchan.g.
include channels_tab.g

//===============================
//      Function Definitions
//===============================

function makecompartment(path, length, dia, Erest)
    str path
    float length, dia, Erest
    float area = length*PI*dia
    float xarea = PI*dia*dia/4

    create      compartment     {path}
    setfield    {path}              \
		Em      { Erest }   \           // volts
		Rm 	{ RM/area } \		// Ohms
		Cm 	{ CM*area } \		// Farads
		Ra      { RA*length/xarea }	// Ohms
end

function makechannel(compartment,channel,Ek,tau1,tau2,gmax)
    str compartment
    str channel
    float Ek                            // Volts
    float tau1,tau2                     // sec
    float gmax                          // Siemens (1/ohms)

    create      synchan               {compartment}/{channel}
    setfield    ^ \
                Ek                      {Ek} \
                tau1                    {tau1} \
                tau2                    {tau2} \
                gmax                    {gmax}
    addmsg   {compartment}/{channel}   {compartment} CHANNEL Gk Ek
    addmsg   {compartment}   {compartment}/{channel} VOLTAGE Vm
end

function makeneuron(path, soma_l, soma_d, dend_l, dend_d)
    str path
    float soma_l, soma_d, dend_l, dend_d

    create neutral {path}
    makecompartment {path}/soma {soma_l} {soma_d} {Eleak}
    setfield {path}/soma initVm {EREST_ACT}

// Create two channels, "{path}/soma/Na_squid_hh" and "{path}/soma/K_squid_hh"
    // USE_TABCHANNEL wybiera implementacje kanalow soma. Oba warianty maja te
    // same stale i te sama parametryzacje alfa/beta; roznia sie tylko typem
    // elementu. Tabelaryczny jest potrzebny, bo hsolve nie obsluguje
    // hh_channel. Patrz channels_tab.g.
    pushe {path}/soma
    if ({USE_TABCHANNEL} == 1)
        make_Na_squid_tab
        make_K_squid_tab
    else
        make_Na_squid_hh
        make_K_squid_hh
    end
    pope

    // The soma needs to know the value of the channel conductance
    // and equilibrium potential in order to calculate the current
    // through the channel.  The channel calculates its conductance
    // using the current value of the soma membrane potential.
    addmsg {path}/soma/Na_squid_hh {path}/soma CHANNEL Gk Ek
    addmsg {path}/soma {path}/soma/Na_squid_hh VOLTAGE Vm
    addmsg {path}/soma/K_squid_hh {path}/soma CHANNEL Gk Ek
    addmsg {path}/soma {path}/soma/K_squid_hh VOLTAGE Vm

    // Rozszerzenie (d): adaptacja czestosci. Kanal powstaje tylko gdy
    // M_channel_gmax > 0, wiec przy domyslnym 0 model jest BIT W BIT
    // taki jak przedtem.
    if ({M_channel_gmax} > 0)
      pushe {path}/soma
      make_M_chan
      pope
      addmsg {path}/soma/M_chan {path}/soma CHANNEL Gk Ek
      addmsg {path}/soma {path}/soma/M_chan VOLTAGE Vm
    end

    // make the dendrite compartment and link it to the soma
    makecompartment {path}/dend1 {dend_l} {dend_d} {EREST_ACT}
    makechannel {path}/dend1 Ex_channel {ENA} {syn_tau1} {syn_tau2} {Ex_channel_gmax}
    // Extension (a): real inhibition. The reference model gave Inh_channel
    // {ENA} = +0.045 V, the SODIUM reversal potential, so the channel named
    // "inhibitory" was depolarising. With rconnect_layers routing 20% of
    // connections to it and weights drawn `rand 0 5` (non-negative), the
    // network was purely excitatory. EK = -0.082 V is defined at line 21 of
    // this file and is what an inhibitory channel needs.
    makechannel {path}/dend1 Inh_channel {Inh_channel_Ek} {syn_tau1} {syn_tau2} {Inh_channel_gmax}
    addmsg {path}/dend1 {path}/soma RAXIAL Ra previous_state
    addmsg {path}/soma {path}/dend1 AXIAL  previous_state

    makecompartment {path}/dend2 {dend_l} {dend_d} {EREST_ACT}
    makechannel {path}/dend2 Ex_channel {ENA} {syn_tau1} {syn_tau2} {Ex_channel_gmax}
    // Extension (a), second dendrite — see dend1 above.
    makechannel {path}/dend2 Inh_channel {Inh_channel_Ek} {syn_tau1} {syn_tau2} {Inh_channel_gmax}
    addmsg {path}/dend2 {path}/soma RAXIAL Ra previous_state
    addmsg {path}/soma {path}/dend2 AXIAL  previous_state

// add a spike generator to the soma
    create spikegen {path}/soma/spike
    setfield {path}/soma/spike  thresh 0  abs_refract 0.010  output_amp 1
    /* use the soma membrane potential to drive the spike generator */
    addmsg  {path}/soma  {path}/soma/spike  INPUT Vm
end  // makeneuron

function makeinput(path)
    str path
    int msgnum
    create randomspike /randomspike
    setfield ^ min_amp 1.0 max_amp 1.0 rate 200 reset 1 reset_value 0
    addmsg /randomspike {path} SPIKE
    msgnum = {getfield {path} nsynapses} - 1
    setfield {path} \
        synapse[{msgnum}].weight 1 synapse[{msgnum}].delay 0
    addmsg /randomspike /data/voltage \
	PLOTSCALE state  *input *blue  0.01     0
// 			  title  color  scale  offset
end


//===============================
//         Main Script
//===============================

// create the neuron "/cell"
//makeneuron /cell {soma_l} {soma_d} {dend_l} {dend_d}
//setfield /cell/soma inject 0.0

//makeinput /cell/dend1/Ex_channel

//--------------------------------------------------------------------
// Rozszerzenie (b), czesc 2: PROTOTYP INTERNEURONU PV.
//
// ⚠️ MUSI stac PO makeneuron, ktore wywoluje. SLI rozstrzyga wywolania funkcji
// przy WCZYTYWANIU, wiec przy odwrotnej kolejnosci caly neuron.g sie nie
// laduje - i nie daje przy tym zadnego komunikatu, tylko cisze.
//
// Rozni sie od piramidowego JEDNYM elementem - kanalem Kv3 na somie. To on
// czyni komorke fast-spiking, wiec dodanie go wystarcza; reszta biofizyki
// zostaje wspolna, co jest zarazem najostrozniejszym wyborem (jedna zmiana,
// jedna przyczyna) i najtanszym (te same tablice kanalow).
//
// ⚠️ To NIE jest pelna charakterystyka interneuronu PV. Prawdziwe komorki PV
// roznia sie tez pojemnoscia, oporem wejsciowym i progiem. Tutaj zmieniamy
// wylacznie to, co jest POTRZEBNE do istnienia osi kv3 i do routingu Ex/Inh
// po tozsamosci. Rozszerzenie (c), heterogenicznosc, jest miejscem na reszte.

function makepvneuron(path, soma_l, soma_d, dend_l, dend_d)
    str path
    float soma_l, soma_d, dend_l, dend_d

    makeneuron {path} {soma_l} {soma_d} {dend_l} {dend_d}

    pushe {path}/soma
    make_Kv3_chan
    pope
    addmsg {path}/soma/Kv3_chan {path}/soma CHANNEL Gk Ek
    addmsg {path}/soma {path}/soma/Kv3_chan VOLTAGE Vm
end
