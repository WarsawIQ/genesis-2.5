// channels_tab.g — kanaly Na i K jako `tabchannel`, matematycznie identyczne
// z `make_Na_squid_hh` / `make_K_squid_hh` z hhchan.g.
//
// PO CO: hsolve nie obsluguje elementow hh_channel. Zeby moc go uzyc na pelnej
// sieci, kanaly musza byc tabelaryczne. To jest zmiana MECHANIZMU, nie
// elektrofizjologii: te same stale, ta sama parametryzacja alfa/beta.
//
// ⚠️ DECYZJA NASZA, NIE AUTORA (2026-08-28). Wojcik nie pamieta, dlaczego
// neuron.g nadpisuje stale z hhchan.g, i zostawil te decyzje nam. Wybor:
// ZACHOWUJEMY stale z neuron.g (EREST_ACT = -0,07, ENA = 0,045, EK = -0,082)
// i zmieniamy wylacznie implementacje. Alternatywa - wziac gotowe prototypy
// hh_tchan.g z ich wlasnymi stalymi (EREST_ACT = -0,060, EK = -0,090) -
// zmienilaby elektrofizjologie modelu i uniewaznila porownania z publikacja
// pierwsza. Kryterium poprawnosci jest wiec sprawdzalne: przebieg Vm ma sie
// zgadzac z wersja hh_channel.
//
// PRZELOZENIE form hh na bramki vdep, wprost z komentarza w hhchan.g:
//   EXPONENTIAL  alpha = A exp((v-V0)/B)
//                -> A'=A     B'=0  C'=0   D'=-V0  F'=-B
//   SIGMOID      alpha = A / (exp((v-V0)/B) + 1)
//                -> A'=A     B'=0  C'=1   D'=-V0  F'=B
//   LINOID       alpha = A (v-V0) / (exp((v-V0)/B) - 1)
//                -> A'=-A*V0 B'=A  C'=-1  D'=-V0  F'=B
// gdzie bramka liczy alpha = (A' + B'*V) / (C' + exp((V+D')/F')).
//
// NAZWY ELEMENTOW zostaja Na_squid_hh i K_squid_hh, mimo ze to juz nie sa
// hh_channel. Robione swiadomie: makeneuron ma cztery addmsg wskazujace na te
// sciezki i kazdy skrypt czytajacy potencjaly tez. Zmiana nazwy dalaby
// czytelniejszy element kosztem rozjazdu wszystkich odwolan. Nazwa jest w tym
// jednym miejscu mylaca - typ elementu sprawdzisz przez {getfield ... class}.
//
// Stale ponizej NIE sa przepisane liczbowo - sa wyrazone przez EREST_ACT,
// ENA, EK i SOMA_A, wiec sledza nadpisania z neuron.g tak samo jak oryginal.

float VMIN_TAB  = -0.15    // zakres tablicy: ponizej EK = -0,082
float VMAX_TAB  =  0.10    // powyzej ENA = 0,045
int   NDIVS_TAB =  3000    // 250 mV / 3000 = 83 uV na podzialke

function make_Na_squid_tab
    if ({exists Na_squid_hh})
        return
    end

    create tabchannel Na_squid_hh
    setfield Na_squid_hh \
        Ek     {ENA} \
        Gbar   {1.2e3 * SOMA_A} \
        Xpower 3.0 \
        Ypower 1.0

    // X (aktywacja m): alpha LINOID, beta EXPONENTIAL
    setupalpha Na_squid_hh X \
        { 0.1e6 * (0.025 + EREST_ACT) }  -0.1e6  -1.0  { -(0.025 + EREST_ACT) }  -0.010 \
        4.0e3  0.0  0.0  { -EREST_ACT }  18.0e-3

    // Y (inaktywacja h): alpha EXPONENTIAL, beta SIGMOID
    setupalpha Na_squid_hh Y \
        70.0  0.0  0.0  { -EREST_ACT }  20.0e-3 \
        1.0e3  0.0  1.0  { -(30.0e-3 + EREST_ACT) }  -10.0e-3
end

// PRZESUNIECIE AKTYWACJI POTASU, w woltach. 0 = model kalamarnicy bez zmian.
//
// ⚠️ PO CO. Stala czasowa blony jest przypieta przez przewodnosc POTASU
// w spoczynku, nie przez wyciek. Zmierzone 2026-09-09 (zadanie 137540):
// trzydziestokrotna zmiana RM nie wydluza odpowiedzi wcale — ustalenie zostaje
// na ~20 ms — bo przy -70 mV n_inf = 0,3177, wiec g_K = 10,37 nS wobec wycieku
// 8,48 nS. RM po prostu nie ma glosu.
//
// Model HH kalamarnicy sluzy do szybkiego przewodzenia impulsu, nie do korowego
// calkowania. Kanaly potasowe kory aktywuja sie przy potencjalach bardziej
// zdepolaryzowanych, wiec w spoczynku praktycznie nie przewodza.
//
// Policzone: przesuniecie o 20 mV daje g_K = 0,064 nS zamiast 10,37 nS — 160
// razy mniej — i RM odzyskuje kontrole: tau = 21,6 ms przy RM = 3,0 wobec 2,4 ms
// teraz. Kora ma 10-30 ms; Deckers i in. 2022 losuja z U[5, 55] ms.
//
// ⚠️ Zmienia to takze ksztalt i repolaryzacje potencjalu czynnosciowego. Sonda
// musi potwierdzic, ze neuron NADAL ODPALA, zanim parametr trafi do przebiegu.
float k_przesuniecie = 0.0

function make_K_squid_tab
    if ({exists K_squid_hh})
        return
    end

    create tabchannel K_squid_hh
    setfield K_squid_hh \
        Ek     {EK} \
        Gbar   {360.0 * SOMA_A} \
        Xpower 4.0 \
        Ypower 0.0

    // X (aktywacja n): alpha LINOID, beta EXPONENTIAL
    //
    // k_przesuniecie przesuwa CALA krzywa aktywacji ku depolaryzacji.
    // Podstawienie V -> V - s w rate(V) = (A + B*V)/(C + exp((V+D)/F)) daje
    // A' = A - B*s oraz D' = D - s; B, C i F zostaja bez zmian.
    setupalpha K_squid_hh X \
        { {10.0e3 * (10.0e-3 + EREST_ACT)} + {10.0e3 * k_przesuniecie} } \
        -10.0e3  -1.0 \
        { {-(10.0e-3 + EREST_ACT)} - k_przesuniecie }  -10.0e-3 \
        125.0  0.0  0.0  { {-EREST_ACT} - k_przesuniecie }  80.0e-3
end

//--------------------------------------------------------------------
// Rozszerzenie (d): ADAPTACJA CZESTOSCI przez prad M.
//
// PO CO: siec bez ujemnego sprzezenia jest bistabilna. Zmierzone 2026-08-29:
// przy Ex_channel_gmax 0,72 siec pali 22,4 Hz, przy 0,68 milczy - cale
// przejscie miesci sie w 6 % zmiany przewodnosci i NIE MA punktu pracy
// w zakresie 1-10 Hz. Hamowanie tego nie naprawi: przy spoczynku -0,070 V ma
// 12 mV sily napedowej wobec 115 mV pobudzenia, wiec jest bocznikujace i slabe
// (zmierzone: 32x hamowania sprowadza 55 Hz tylko do 31,5 Hz).
//
// Prad M jest ujemnym sprzezeniem WEWNATRZ neuronu: aktywuje sie powoli przy
// depolaryzacji i tlumi kolejne odpalenia. To on tworzy rezim stopniowany
// zamiast przeskoku cisza/lawina.
//
// DLACZEGO M, A NIE AHP ZALEZNE OD WAPNIA: prad M jest wylacznie napieciowy,
// wiec wchodzi w istniejaca infrastrukture tabchannel. AHP wymagaloby puli
// wapnia (concen), kanalu wapniowego i kanalu K(Ca) - trzech nowych elementow
// na neuron przy 65 536 neuronach. Deckers 2022 traktuje oba jako
// rownowazne zrodla adaptacji.
//
// KINETYKA: standardowa postac pradu M (Adams i in.), przeliczona na SI:
//   alpha = A1 (V-V0) / (1 - exp(-(V-V0)/B1))     A1 = 100 1/(V s)
//   beta  = -A1 (V-V0) / (1 - exp((V-V0)/B1))     V0 = -0,030 V, B1 = 0,009 V
// Stala czasowa w poblizu V0 wynosi 1/(alpha+beta) = 1/(2 A1 B1) ~ 550 ms.
// To jest wolne nawet jak na prad M; skalowanie M_rate_scale przyspiesza go
// proporcjonalnie, bo mnozy oba wspolczynniki.
//
// PRZELOZENIE LINOID -> bramka vdep (jak wyzej): A'=-A*V0, B'=A, C'=-1,
// D'=-V0, F'=B, przy czym dla alfa bierzemy A=-A1, B=-B1, a dla bety A=A1,
// B=B1 - to odwraca znak mianownika z (exp(x)-1) na (1-exp(-x)).

float M_channel_gmax = 0.0     // 0 = WYLACZONY, model odniesienia bez zmian
float M_rate_scale   = 1.0     // >1 przyspiesza adaptacje

function make_M_chan
    if ({exists M_chan})
        return
    end

    create tabchannel M_chan
    setfield M_chan \
        Ek     {EK} \
        Gbar   {M_channel_gmax} \
        Xpower 1.0 \
        Ypower 0.0

    setupalpha M_chan X \
        { -100.0 * M_rate_scale * -0.030 }  { -100.0 * M_rate_scale }  -1.0  0.030  -0.009 \
        {  100.0 * M_rate_scale * -0.030 }  {  100.0 * M_rate_scale }  -1.0  0.030   0.009
end

//--------------------------------------------------------------------
// Rozszerzenie (b), czesc 1: KANAL Kv3 dla interneuronow PV.
//
// Kv3 to szybki, wysokoprogowy kanal potasowy. Jego rola jest scisle
// funkcjonalna: skraca repolaryzacje, dzieki czemu komorka moze odpalac
// z wysoka czestoscia bez wchodzenia w blok depolaryzacyjny. Bez niego
// "interneuron fast-spiking" nie jest fast-spiking.
//
// PO CO NAM: os uszkodzenia `kv3` (eLife 75316) nie ma dzis w modelu ZADNEGO
// substratu - nie ma ani kanalu Kv3, ani populacji, ktora by go niosla.
// kv3_gmax_scale z lsmcd/lesion/axes.py wskazuje na nic. Ten kanal to zmienia.
//
// KINETYKA: standardowa postac Kv3.1, przeliczona na SI:
//   alpha = 0,02 (V-25) / (1 - exp(-(V-25)/9))     [mV, 1/ms]
//   beta  = -0,002 (V-25) / (1 - exp((V-25)/9))
// czyli A1 = 20000 i -2000 1/(V s), V0 = 0,025 V, B1 = ±0,009 V.
// Stala czasowa przy V0 wynosi 5,05 ms - szybka, zgodnie z rola kanalu.
//
// Przelozenie LINOID -> bramka vdep jak przy pradzie M; wyprowadzenie w
// naglowku tamtego kanalu.

float kv3_gmax        = 0.0    // 0 = brak kanalu; ustawiane przy budowie PV
float kv3_gmax_scale  = 1.0    // GALKA USZKODZENIA, patrz lsmcd.lesion.axes

function make_Kv3_chan
    if ({exists Kv3_chan})
        return
    end

    create tabchannel Kv3_chan
    setfield Kv3_chan \
        Ek     {EK} \
        Gbar   {kv3_gmax * kv3_gmax_scale} \
        Xpower 1.0 \
        Ypower 0.0

    setupalpha Kv3_chan X \
        500.0  -20000.0  -1.0  -0.025  -0.009 \
         50.0   -2000.0  -1.0  -0.025   0.009
end
