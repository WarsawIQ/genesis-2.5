// run_configuration.g — sterownik JEDNEJ konfiguracji sweepu.
//
// Produkuje surowce, ktore postprocess.py zamienia na artefakty z
// docs/PIPELINE.md: synapses.txt, states.npy, lfp.npy, meta.json.
//
// Wszystkie mechanizmy uzyte tutaj sa zweryfikowane osobno na Lunar
// (2026-08-28); przy kazdym stoi probnik, ktory to pokazuje.
//
// KONFIGURACJA przychodzi w config.g, generowanym przez postprocess.py:
//   str  WYJSCIE            katalog na wyniki
//   str  KAT_SPK            katalog z plikami czasow dla siatkowki
//   int  N_PROBEK           liczba probek
//   float OKNO_PROBKI       dlugosc okna probki w sekundach (0,200)
//   float PRZERWA           przerwa miedzy probkami w sekundach (0,100)
//   float LFP_SEKUND        dlugosc ciaglego sladu LFP (60,0)
//   float LFP_FS            czestotliwosc zapisu LFP w Hz (500)
//   int  ZIARNO             randseed przed budowa
//   int  UZYJ_HSOLVE        1 wlacza hsolve (chanmode 1)
//   float TLO_HZ            czestosc bombardowania Poissona na kanalach
//                           pobudzajacych rezerwuaru (0 = brak)
//   int  G_NODES, G_NX, G_NY, G_NZ, G_PATCH   geometria; nadpisuje pparameters.g,
//        zeby pilot mogl biec na mniejszej sieci bez edycji modelu
//
// ⚠️ PRZERWA kosztuje. 400 probek po 200 ms to 80 s symulacji; z przerwa
// 100 ms to 120 s, czyli 1,5x drozej. Przerwa jest tu, bo bez niej stan
// cieczy z probki n przecieka do n+1 i etykiety przestaja opisywac to, co
// siec faktycznie widziala. Skrocenie jej to decyzja naukowa, nie oszczednosc.

include pparameters.g
include neuron.g
include construct_serial.g
include scan_serial.g
include config.g

// Geometria z konfiguracji nadpisuje pparameters.g. Musi stac PRZED budowa
// i przed nadpisaniami uszkodzen, bo obie ich uzywaja.
NodesNumber = {G_NODES}
array_Nx    = {G_NX}
array_Ny    = {G_NY}
array_Nz    = {G_NZ}
patchdim    = {G_PATCH}

randseed {ZIARNO}

// ---- 1. nadpisania parametrow -------------------------------------------
// PUNKT WLACZENIA 1: po neuron.g i construct_serial.g (zeby symbole
// istnialy), ale PRZED makeneuron.
//
// ⚠️ MUSI BYC PRZED PROTOTYPAMI. makeneuron czyta Ex_channel_gmax w chwili
// wywolania i zapisuje go w polu gmax elementu synchan. Nadpisanie zmiennej
// PO zbudowaniu prototypu nie zmienia juz niczego, a GENESIS nie zglasza
// bledu — dostaje sie siec zdrowa pod nazwa uszkodzonej.
//
// Zmierzone 2026-09-04, zadania 137302-137307: przy tym pliku wlaczonym po
// makeneuron szesc przebiegow o krotnosci Ex od 0,30 do 1,00 dalo
// IDENTYCZNE 2 983 764 odpalen. Odczyt zwrotny nizej istnieje po to, zeby
// taka pomylka nie przeszla po cichu drugi raz.
include lesion_params.g

// Nadpisania osi PARAMETRYCZNYCH (ei_imbalance, kv3) — osobny plik, bo
// lesion_params.g niesie parametry substratu, a te sa uszkodzeniem.
// Rozdzielenie jest po to, zeby meta.json odroznil jedno od drugiego.
include lesion_extra.g

// ---- 2. prototypy -------------------------------------------------------
// ⚠️ PROTOTYP PV MUSI POWSTAC PRZED make_brain. Przy pv_every > 0 make_brain
// kopiuje czesc komorek z /pv_cell i PRZERYWA z bledem, gdy go nie ma —
// construct_serial.g sprawdza to jawnie. Dotad sterownik go nie tworzyl, wiec
// samo ustawienie pv_every w pliku nadpisan konczylo sie bledem budowy zamiast
// wlaczeniem rozszerzenia. Warunek zostawia siec bez PV bit w bit taka sama.
if ({pv_every} > 0)
    makepvneuron /pv_cell {soma_l} {soma_d} {dend_l} {dend_d}
    setfield /pv_cell/soma inject 0.0
    echo "PROTOTYP PV utworzony, pv_every =" {pv_every}
end

makeneuron /brain_cell   {soma_l} {soma_d} {dend_l} {dend_d}
setfield   /brain_cell/soma inject 0.0
makeneuron /retinal_cell {soma_l} {soma_d} {dend_l} {dend_d}
setfield   /retinal_cell/soma inject 0.0
makeneuron /readout_cell {soma_l} {soma_d} {dend_l} {dend_d}
setfield   /readout_cell/soma inject 0.0

// ---- 3. budowa ----------------------------------------------------------
make_brain     /brain_cell   /brain   {array_Nx} {array_Ny} {array_Nz}
make_retina    /retinal_cell /retina
make_readout_s /readout_cell /readout
connect_in_layers          /brain
connect_layers_in_columns  /brain
connect_columns            /brain
connect_retina_with_LSM_s  /retina /brain
connect_readout_with_LSM_s /readout /brain
echo "SIEC ZBUDOWANA"

// ⚠️ ODCZYT ZWROTNY, nie ozdoba. Czyta gmax z FAKTYCZNIE zbudowanej komorki,
// a nie ze zmiennej SLI — tylko to odroznia nadpisanie, ktore weszlo, od
// nadpisania, ktore sie nie odbylo. Porownaj z lesion_params.g w logu.
echo "SPRAWDZENIE Ex_channel gmax =" {getfield /brain1_1_1_1/dend1/Ex_channel gmax}
echo "SPRAWDZENIE Inh_channel gmax =" {getfield /brain1_1_1_1/dend1/Inh_channel gmax}

// Parametry BLONY maja dokladnie te sama pulapke co Ex_channel_gmax: RM i Eleak
// sa czytane przez makecompartment w chwili wywolania, wiec nadpisanie po
// prototypach nie zmienia niczego i GENESIS nic nie zglasza. Czytamy je
// z FAKTYCZNIE zbudowanej somy.
echo "SPRAWDZENIE soma Rm =" {getfield /brain1_1_1_1/soma Rm}
echo "SPRAWDZENIE soma Em =" {getfield /brain1_1_1_1/soma Em}
echo "SPRAWDZENIE soma Cm =" {getfield /brain1_1_1_1/soma Cm}
echo "SPRAWDZENIE tau_bierna_ms =" {{{getfield /brain1_1_1_1/soma Rm} * {getfield /brain1_1_1_1/soma Cm}} * 1000}

// ⚠️ TO JEDNO jest odczytem ZMIENNEJ, nie komorki, bo przesuniecie krzywej
// aktywacji siedzi w tablicy kanalu i nie da sie go odczytac jedna liczba.
// Sprawdzenie na poziomie komorki robi model/probes/tau_probe.g, ktory mierzy
// stala czasowa i potwierdza, ze neuron nadal odpala. Nie mylic jednego
// z drugim: ten wiersz dowodzi tylko, ze plik nadpisan zostal wciagniety.
echo "SPRAWDZENIE zmiennej k_przesuniecie =" {k_przesuniecie}

// Tozsamosc komorek: ile z nich jest interneuronami PV. Czytane z FAKTYCZNIE
// zbudowanej siatki, bo pv_every to dzielnik, a nie udzial — przy pv_every = 5
// wychodzi 20 %, ale tylko wtedy, gdy mieszanie trafia rownomiernie.
// ⚠️ LICZYMY UDZIAL, NIE PYTAMY O JEDNA KOMORKE. Pierwsza wersja sprawdzala
// /brain1_1_1_1 — komorke, ktora przy pv_every = 5 akurat NIE jest PV. Zero
// w odpowiedzi wygladalo jak wynik, a nie znaczylo nic. Przechodzimy siatke
// i liczymy, ile komorek faktycznie niesie kanal Kv3.
if ({pv_every} > 0)
    int pv_jest = 0
    int pv_razem = 0
    int q, qi, qj, qk
    for (q = 1; q <= {NodesNumber}; q = q + 1)
      for (qi = 1; qi <= {array_Nx}; qi = qi + 1)
        for (qj = 1; qj <= {array_Ny}; qj = qj + 1)
          for (qk = 1; qk <= {array_Nz}; qk = qk + 1)
            pv_razem = pv_razem + 1
            if ({exists /brain{q}_{qi}_{qj}_{qk}/soma/Kv3_chan} == 1)
              pv_jest = pv_jest + 1
            end
          end
        end
      end
    end
    echo "SPRAWDZENIE komorek PV =" {pv_jest} "z" {pv_razem} \
         "czyli" {{pv_jest * 100.0} / pv_razem} "%"
end

// Waga synapsy WEJSCIOWEJ, czytana z sieci. Kolejnosc laczenia to gwarantuje:
// connect_retina_with_LSM_s biegnie jako ostatnia z funkcji celujacych w
// dend1/Ex_channel warstwy 1, wiec najwyzszy indeks jest synapsa siatkowki.
// Bez tego retina_weight_scale bylby sprawdzany tylko przez odczyt zmiennej,
// a wlasnie taki odczyt przepuscil awarie Ex_channel_gmax.
int liczba_synaps = {getfield /brain1_1_1_1/dend1/Ex_channel nsynapses}
int ostatnia_synapsa = {liczba_synaps - 1}
echo "SPRAWDZENIE synaps na dend1/Ex_channel =" {liczba_synaps}
echo "SPRAWDZENIE waga wejscia z siatkowki =" \
     {getfield /brain1_1_1_1/dend1/Ex_channel synapse[{ostatnia_synapsa}].weight}

// ---- 4. usuniecia synaps ------------------------------------------------
// PUNKT WLACZENIA 2: po budowie. Zerowanie wagi wymaga istniejacej synapsy.
include removals.g

// ---- 5. skan rezerwuaru -------------------------------------------------
// Po uszkodzeniu, zeby zapis odpowiadal sieci, ktora faktycznie liczy.
skanuj_rezerwuar /brain {WYJSCIE}/synapses.txt

// ---- 6. wejscie: timetable na komorke siatkowki -------------------------
// ⚠️ maxtime MUSI byc ustawione. Bez tego TABFILL wczytuje JEDEN wpis
// i milczy (sprawdzone 2026-08-28).
// ⚠️ Wpiecie przez ACTIVATION, nie SPIKE. timetable nie wysyla komunikatow
// ("Messages: [none]"); SPIKE rejestruje sie jako synapsa i nie dostarcza nic.
float CZAS_BODZCA = {N_PROBEK} * ({OKNO_PROBKI} + {PRZERWA})
// ⚠️ maxtime musi obejmowac czas BEZWZGLEDNY ostatniego zdarzenia, a czasy sa
// przesuniete o faze LFP, ktora biegnie pierwsza. Ustawienie samego
// CZAS_BODZCA obcina WSZYSTKIE zdarzenia i TABFILL laduje wtedy jeden wpis -
// objawem jest pojedynczy zaplon na poczatku fazy probek i cisza potem.
float KONIEC_BODZCA = {LFP_SEKUND} + {CZAS_BODZCA}
int tn, ti, tj
for (tn=1; tn<={NodesNumber}; tn={tn+1})
  for (ti=1; ti<={patchdim}; ti={ti+1})
    for (tj=1; tj<={patchdim}; tj={tj+1})
      create timetable /tt{tn}_{ti}_{tj}
      setfield /tt{tn}_{ti}_{tj} \
               method 4 \
               fname {KAT_SPK}/retina_{tn}_{ti}_{tj}.txt \
               act_val 1 \
               maxtime {KONIEC_BODZCA}
      call /tt{tn}_{ti}_{tj} TABFILL
      addmsg /tt{tn}_{ti}_{tj} /retina{tn}_{ti}_{tj}/dend1/Ex_channel \
             ACTIVATION activation
      // Przewodnosc PRZEKAZNIKA. Dotyczy wylacznie komorek siatkowki - ich
      // Ex_channel sluzy tylko do wejscia z timetable, wiec rezerwuaru to nie
      // rusza. Skalibrowane 2026-08-28: przy 1e-5 zero odpalen, przy 1e-4
      // dokladnie jedno na zdarzenie, i tak zostaje az do 1e-2 (refrakcja).
      // Bierzemy 1e-3, czyli srodek plaskowyzu.
      //
      // Dlaczego az tyle: ACTIVATION ustawia act_val na JEDEN krok (50 us),
      // a kanal ma tau 3 ms - taki impuls wnosi znikomy ladunek w porownaniu
      // ze zdarzeniem SPIKE, ktore jest wazona delta. To nie jest wzmocnienie
      // synapsy, tylko przeliczenie impulsu jednokrokowego na zdarzenie.
      setfield /retina{tn}_{ti}_{tj}/dend1/Ex_channel gmax 1e-3
    end
  end
end
echo "WEJSCIE PODLACZONE"

// ---- 7. zapis odpalen rezerwuaru ----------------------------------------
// ⚠️ pole nazywa sie filename, nie fname.
create spikehistory /spikes
setfield /spikes filename {WYJSCIE}/spikes.txt ident_toggle 1 append 0 leave_open 1
int sn, sx, sy, sz
for (sn=1; sn<={NodesNumber}; sn={sn+1})
  for (sx=1; sx<={array_Nx}; sx={sx+1})
    for (sy=1; sy<={array_Ny}; sy={sy+1})
      for (sz=1; sz<={array_Nz}; sz={sz+1})
        addmsg /brain{sn}_{sx}_{sy}_{sz}/soma/spike /spikes SPIKESAVE
      end
    end
  end
end

// ---- 8. LFP -------------------------------------------------------------
// Zegar 2, bo zegary 0-2 sa w domyslnym harmonogramie; zegar 3 nie jest
// stepowany i plik w ogole nie powstaje (sprawdzone).
setclock 0 0.00005
setclock 1 0.00005
setclock 2 {1.0 / LFP_FS}

create asc_file /lfp
setfield /lfp filename {WYJSCIE}/lfp.txt leave_open 1 append 0
useclock /lfp 2

// Elektroda: po jednej komorce z kazdego bloku pokrycia siatkowki, wszystkie
// cztery kanaly synaptyczne. Sumowanie zostawiamy Pythonowi, zeby dalo sie
// pozniej wazyc odlegloscia bez powtarzania symulacji.
// ⚠️ Elektroda ma STALA liczbe kanalow, niezalezna od geometrii.
//
// Pierwotnie brala "po jednej komorce z bloku pokrycia siatkowki", czyli
// co (Nx/patchdim). Przy patchdim = Nx blok ma rozmiar 1, wiec probkowala
// KAZDA komorke: 1024 kanaly zamiast garstki, i lfp.txt urosl do 680 MB na
// konfiguracje. Przy 111 konfiguracjach to 75 GB.
//
// Teraz krok to polowa boku warstwy, wiec wychodza 4 pozycje na kolumne
// niezaleznie od Nx, Ny i patchdim - czyli 16 kanalow na kolumne.
// Sprawdzone: Nx=8/patchdim=8 dawalo 64 pozycje, teraz 4.
int lx, ly, bkx, bky
bkx = {array_Nx / 2}
bky = {array_Ny / 2}
if (bkx < 1)
  bkx = 1
end
if (bky < 1)
  bky = 1
end
for (sn=1; sn<={NodesNumber}; sn={sn+1})
  for (lx=1; lx<={array_Nx}; lx={lx+bkx})
    for (ly=1; ly<={array_Ny}; ly={ly+bky})
      addmsg /brain{sn}_{lx}_{ly}_1/dend1/Ex_channel  /lfp SAVE Ik
      addmsg /brain{sn}_{lx}_{ly}_1/dend1/Inh_channel /lfp SAVE Ik
      addmsg /brain{sn}_{lx}_{ly}_1/dend2/Ex_channel  /lfp SAVE Ik
      addmsg /brain{sn}_{lx}_{ly}_1/dend2/Inh_channel /lfp SAVE Ik
    end
  end
end

// ---- 9. hsolve (opcjonalnie) --------------------------------------------
// ⚠️ TYLKO chanmode 1. Od trybu 2 w gore spikegen przestaje odpalac, od 3
// w gore znika dostep do Vm komory - patrz model/probes/hsolve_spike_test.g.
if ({UZYJ_HSOLVE} == 1)
  int hn, hx, hy, hz
  for (hn=1; hn<={NodesNumber}; hn={hn+1})
    for (hx=1; hx<={array_Nx}; hx={hx+1})
      for (hy=1; hy<={array_Ny}; hy={hy+1})
        for (hz=1; hz<={array_Nz}; hz={hz+1})
          create hsolve /brain{hn}_{hx}_{hy}_{hz}/solve
          setfield /brain{hn}_{hx}_{hy}_{hz}/solve \
                   path /brain{hn}_{hx}_{hy}_{hz}/##[][TYPE=compartment] \
                   chanmode 1
          call /brain{hn}_{hx}_{hy}_{hz}/solve SETUP
        end
      end
    end
  end
  setmethod 11
  echo "HSOLVE PODLACZONY"
end

// ---- 9a. bombardowanie tla ------------------------------------------------
// ⚠️ BEZ TEGO FAZA LFP JEST DOKLADNIE ZEROWA. Sprawdzone 2026-08-30 na
// pilocie SHD: lfp.npy mial poprawny ksztalt (1000 probek) i same zera, bo
// w fazie ciszy nie ma ani bodzca, ani zadnego innego zrodla pradu. Biomarkery
// widmowe nie mialy wtedy czego liczyc.
//
// `frequency` na synchanie to wbudowane w GENESIS losowe pobudzanie kanalu.
// Reprezentuje wejscie z reszty kory, ktorej nie symulujemy - modelujemy
// 65 tys. neuronow kolumny, a nie mozg. Zmierzone przy kalibracji: ponizej
// ~15 Hz siec milczy, powyzej siada w rezimie 26-58 Hz.
//
// ⚠️ TLO MUSI BYC PODPROGOWE. Przy TLO_HZ = 20 samo tlo pali siec na 48 Hz
// (147 659 odpalen w 2 s fazy ciszy) i CALKOWICIE ZAGLUSZA BODZIEC: przeglad
// sily wejscia dal wtedy 6,02 mln odpalen przy wadze 0,9, 0,7 i 0,5 —
// identycznie, bo siec byla wysycona niezaleznie od wejscia.
//
// Kalibracja (zadanie 137186) pokazuje wlasciwy zakres: przy 1-10 Hz LFP jest
// juz NIEZEROWE (977 niezerowych wartosci), a odpalen ZERO. To jest reżim,
// ktorego chcemy — prad synaptyczny podprogowy daje slad widmowy, nie
// przejmujac sieci. Powyzej ~15 Hz siec zapala sie i tlo staje sie bodzcem.
//
// SPRAWDZONE 2026-08-30 przy TLO_HZ = 20: LFP ma 77 710 niezerowych wartosci
// zamiast samych zer, a rezerwuar odpala takze w fazie ciszy. Pierwsze linie
// pozostaja zerowe - bombardowanie Poissona potrzebuje chwili, zeby sie
// rozkrecic - i to jest oczekiwane, nie usterka.
if ({TLO_HZ} > 0)
  int bn, bx, by, bz
  for (bn=1; bn<={NodesNumber}; bn={bn+1})
    for (bx=1; bx<={array_Nx}; bx={bx+1})
      for (by=1; by<={array_Ny}; by={by+1})
        for (bz=1; bz<={array_Nz}; bz={bz+1})
          setfield /brain{bn}_{bx}_{by}_{bz}/dend1/Ex_channel frequency {TLO_HZ}
          setfield /brain{bn}_{bx}_{by}_{bz}/dend2/Ex_channel frequency {TLO_HZ}
        end
      end
    end
  end
  echo "TLO PODLACZONE" {TLO_HZ} "Hz"
end

reset

// ---- 10. faza LFP: cisza, ciagly slad ----------------------------------
// Osobno od probek, bo biomarkery widmowe sa spoczynkowe. Kontrakt mowi
// wprost: nie liczy sie ich z okien bodzcowych.
echo "FAZA LFP" {LFP_SEKUND} "s"
step {LFP_SEKUND} -time
echo "LFP GOTOWE"

// ---- 11. faza probek ----------------------------------------------------
// Jeden ciagly przebieg; granice okien odtwarza postprocess.py z czasow
// odpalen, bo spikehistory zapisuje czas kazdego zdarzenia.
echo "FAZA PROBEK" {CZAS_BODZCA} "s"
step {CZAS_BODZCA} -time
echo "PROBKI GOTOWE"

quit
