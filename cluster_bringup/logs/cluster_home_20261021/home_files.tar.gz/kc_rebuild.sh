#!/bin/sh
ROOT=$HOME/genesis-2.5; SRC=$ROOT/genesis/src
CUDA_HOME=/storage/opt/cuda/cuda-12.8
export PATH="$CUDA_HOME/bin:$PATH"
CC=$(command -v gcc)
cc=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d ". ")
ARCH="sm_${cc:-80}"
STUB="$ROOT/locallib/libfl.a"
EXTRALIBS="sprng/lib/liblfg.a -lncurses -ltinfo -lOpenCL -L$CUDA_HOME/lib64 -lcudart -lstdc++"
echo "ARCH=$ARCH na $(hostname)"
cd $SRC
rm -f hines/hineslib.o hines/hines.o hines/cuda/cuda_hsolve.o hines/opencl/ocl_hsolve.o
make USE_CUDA=1 CUDA_HOME="$CUDA_HOME" NVCCFLAGS="-arch=$ARCH -ccbin $CC" \
     EXTRALIBS="$EXTRALIBS" LEXLIB="$STUB" nxgenesis 2>&1 | tail -5
echo "=== MAKE EXIT $? ==="
