import arbor as A
from arbor import units as U
s = A.poisson_schedule(tstart=0*U.ms, freq=(1000.0/70.0)*U.Hz, seed=1, tstop=50*U.ms)
ev = s.events(0*U.ms, 5000*U.ms)
print("events in 0-5000 ms:", len(ev), "last:", ev[-1] if len(ev) else None)
