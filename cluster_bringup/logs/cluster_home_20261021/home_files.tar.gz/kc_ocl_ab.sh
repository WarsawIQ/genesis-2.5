#!/bin/sh
# A/B: OpenCL backend before vs after the per-hsolve refactor.
cd $HOME/genesis-2.5
G=$HOME/golden_opencl.txt
cp -p genesis/src/nxgenesis genesis/src/nxgenesis.cuda-bak 2>/dev/null

echo "########## A: zrodla SPRZED refaktoru ##########"
cp -f $HOME/ocl_pre/ocl_hsolve.c $HOME/ocl_pre/ocl_hsolve.h genesis/src/hines/opencl/
sh cluster_bringup/11_build_opencl.sh 2>&1 | tail -3
ACCEL_GOLDEN=$G sh cluster_bringup/80_accel_regression.sh record 2>&1 | tail -3

echo "########## B: zrodla PO refaktorze ##########"
cp -f $HOME/ocl_cur/ocl_hsolve.c $HOME/ocl_cur/ocl_hsolve.h genesis/src/hines/opencl/
sh cluster_bringup/11_build_opencl.sh 2>&1 | tail -3
ACCEL_GOLDEN=$G sh cluster_bringup/80_accel_regression.sh check 2>&1 | tail -25

cp -p genesis/src/nxgenesis.cuda-bak genesis/src/nxgenesis 2>/dev/null
echo "########## KONIEC ##########"
