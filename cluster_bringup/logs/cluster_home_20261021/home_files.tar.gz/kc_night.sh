#!/bin/sh
# Nocna kolejka. Czeka na sweep (marker), potem rozszerza skalowanie i na koniec
# potwierdza, ze drzewo jest zielone po dzisiejszych zmianach.
R=$HOME/genesis-2.5
LOG=$HOME/night.log
exec >> $LOG 2>&1
echo "===== START $(date +%F\ %T) ====="

# 1) poczekaj na biezacy sweep (bez pgrep -- samotrafienie)
while [ -z "$(grep -c KONIEC $HOME/vanet_sweep.log 2>/dev/null | grep -v ^0$)" ]; do sleep 30; done
echo "-- sweep podstawowy zakonczony --"
cat $HOME/vanet2_cpu_scaling.csv

# 2) rozszerzenie skalowania: wiekszy N, konstrukcja + przebieg
BIN=$R/genesis/src/nxgenesis_nocl
CSV=$HOME/vanet2_cpu_scaling_big.csv
echo "ex_nx,ex_ny,inh_nx,inh_ny,n_cells,wall_s,vm_lines" > $CSV
for dims in "200 156 100 78" "256 200 128 100"; do
  set -- $dims; EX=$1; EY=$2; IX=$3; IY=$4
  N=$(( EX*EY + IX*IY )); D=$HOME/vanet_big_$N
  rm -rf $D; mkdir -p $D
  cp $R/genesis/Scripts/VAnet2/*.g $R/genesis/Scripts/VAnet2/*.p $D/
  printf "setenv SIMPATH . %s/genesis/startup %s/genesis/Scripts/neurokit %s/genesis/Scripts/neurokit/prototypes\nsetenv SIMNOTES %s/.notes\nsetenv GENESIS_HELP %s/genesis/Doc\nschedule\n" "$R" "$R" "$R" "$HOME" "$R" > $D/.simrc
  sed -i "s/^int Ex_NX = .*/int Ex_NX = $EX; int Ex_NY = $EY/" $D/VAnet2-batch.g
  sed -i "s/^int Inh_NX = .*/int Inh_NX = $IX; int Inh_NY = $IY/" $D/VAnet2-batch.g
  echo "== BIG N=$N == $(date +%T)"
  S=$(date +%s.%N); ( cd $D && timeout 10800 $BIN -notty -batch VAnet2-batch.g > out.log 2>&1 ); RC=$?; E=$(date +%s.%N)
  W=$(echo "$E - $S" | bc); L=$(wc -l < $D/Vm_out_1000.txt 2>/dev/null || echo 0)
  echo "$EX,$EY,$IX,$IY,$N,$W,$L" >> $CSV
  echo "   exit=$RC wall=${W}s lines=$L"
done
cat $CSV

# 3) potwierdz, ze drzewo jest zielone po dzisiejszych commitach
echo "-- regresja CUDA --"
sh $R/cluster_bringup/80_accel_regression.sh check
echo "===== KONIEC $(date +%F\ %T) ====="
