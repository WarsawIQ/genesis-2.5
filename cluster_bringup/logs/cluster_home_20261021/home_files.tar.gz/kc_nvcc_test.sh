#!/bin/sh
cd $HOME/genesis-2.5/genesis/src/hines
CUDA_HOME=/storage/opt/cuda/cuda-12.8
export PATH="$CUDA_HOME/bin:$PATH"
rm -f cuda/cuda_backend.o
make USE_CUDA=1 CUDA_HOME="$CUDA_HOME" \
     CFLAGS_IN="-O2 -DLONGWORDS -std=gnu89 -fPIC -DINCSPRNG -DNO_X" \
     MACHINE=Linux LD=ld cuda/cuda_backend.o 2>&1 | grep -E "nvcc|Error" | head -3
n=$(readelf -r cuda/cuda_backend.o 2>/dev/null | grep -cE "R_X86_64_32S?[[:space:]]")
echo "cuda_backend.o: abs-reloc=$n -> $([ "$n" -eq 0 ] && echo PIC || echo NIE-PIC)"
