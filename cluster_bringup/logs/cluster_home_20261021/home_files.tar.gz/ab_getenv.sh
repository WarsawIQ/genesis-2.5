#!/bin/sh
# A/B na jednej maszynie: hines.c z cache getenv i bez.
R=$HOME/genesis-2.5
cp $R/genesis/src/hines/hines.c $HOME/hines_fixed.c
run3() {
  cd $HOME/vanet2_regression-cpu
  for r in 1 2 3; do
    rm -f Vm_out_1000.txt
    S=$(date +%s%N)
    timeout 900 $R/genesis/src/nxgenesis_nocl -notty -batch VAnet2-batch.g >/dev/null 2>&1
    E=$(date +%s%N)
    awk "BEGIN{printf \"  %.2f\n\", ($E-$S)/1e9}"
  done
  md5sum Vm_out_1000.txt | cut -c1-12
}
for V in head fixed; do
  if [ "$V" = head ]; then cp $HOME/hines_head.c $R/genesis/src/hines/hines.c
  else cp $HOME/hines_fixed.c $R/genesis/src/hines/hines.c; fi
  cd $R && sh cluster_bringup/10_build.sh >/dev/null 2>&1
  echo "=== $V ==="
  run3
done
cp $HOME/hines_fixed.c $R/genesis/src/hines/hines.c
cd $R && sh cluster_bringup/10_build.sh >/dev/null 2>&1
echo "=== przywrocono wersje z poprawka ==="
