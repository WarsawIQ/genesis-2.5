#!/bin/bash
# Build NEURON with CoreNEURON GPU offload, so the head-to-head can exercise the
# configuration CoreNEURON is actually designed for.
#
# The comparison reported so far is single-threaded CPU on both sides, which is
# the weakest form of the claim: CoreNEURON targets GPU and multi-rank MPI. This
# builds the GPU path (OpenACC via NVHPC) against the same COBAHH model.
set -eu

NVHPC="$HOME/opt/nvhpc"
CUDAV=12.8
# NVHPC ships its own CUDA; use its bin/lib so nvc++ and the runtime agree.
export NVHPC_ROOT="$NVHPC/Linux_x86_64/$(ls "$NVHPC/Linux_x86_64" 2>/dev/null | head -1)"
export PATH="$NVHPC_ROOT/compilers/bin:$PATH"
export LD_LIBRARY_PATH="$NVHPC_ROOT/compilers/lib:${LD_LIBRARY_PATH:-}"

command -v nvc++ >/dev/null || { echo "ERROR: nvc++ not on PATH ($NVHPC_ROOT)" >&2; exit 1; }
echo "nvc++: $(nvc++ --version | head -2 | tail -1)"

SRC="$HOME/nrn_src"
BUILD="$SRC/build-gpu"
PREFIX="$HOME/opt/nrn-gpu"

if [ ! -d "$SRC/.git" ]; then
    git clone --depth 1 --branch 9.0.2 https://github.com/neuronsimulator/nrn.git "$SRC"
fi
cd "$SRC"
git submodule update --init --recursive --depth 1 || true

rm -rf "$BUILD"; mkdir -p "$BUILD"; cd "$BUILD"

# A40 is sm_86, A100 is sm_80; build for both so one tree runs on either node.
cmake .. \
    -DCMAKE_INSTALL_PREFIX="$PREFIX" \
    -DCMAKE_C_COMPILER=nvc \
    -DCMAKE_CXX_COMPILER=nvc++ \
    -DNRN_ENABLE_CORENEURON=ON \
    -DCORENRN_ENABLE_GPU=ON \
    -DCMAKE_CUDA_ARCHITECTURES="80;86" \
    -DCMAKE_CUDA_COMPILER="$NVHPC_ROOT/cuda/$CUDAV/bin/nvcc" \
    -DNRN_ENABLE_INTERVIEWS=OFF \
    -DNRN_ENABLE_RX3D=OFF \
    -DNRN_ENABLE_MPI=OFF \
    -DNRN_ENABLE_PYTHON=ON \
    -DPYTHON_EXECUTABLE="$(command -v python3.12)" \
    -DCMAKE_BUILD_TYPE=Release \
    > cmake.log 2>&1 || { echo "CMAKE FAILED"; tail -30 cmake.log; exit 1; }

echo "cmake ok, building (this takes a while) ..."
make -j"$(nproc)" > make.log 2>&1 || { echo "BUILD FAILED"; grep -iE "error" make.log | head -20; exit 1; }
make install > install.log 2>&1

echo "=== installed ==="
ls -la "$PREFIX/bin/" 2>/dev/null | head
"$PREFIX/bin/nrniv" -c 'print "neuron ok"' 2>&1 | tail -2 || true
