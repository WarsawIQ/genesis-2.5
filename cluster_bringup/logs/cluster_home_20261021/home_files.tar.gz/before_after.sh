#!/bin/sh
# inf03: the spike-start and reset checks on rc2 (before) and on the fix (after)
export WORK_DIR=$HOME/tc-verify-20260929
echo "=== BEFORE: v2.6.0-rc2 binaries"
cd ~/campaign-dry-inf03 && sh cluster_bringup/campaign/spike_start_check.sh; echo "exit $?"
echo "=== building the fix (9ec9c33)"
cd ~/fix-dev && CAMPAIGN_DRY=1 sh cluster_bringup/campaign/prepare_node.sh > ~/fix-dev-build.log 2>&1; echo "build exit $?"
echo "=== AFTER: the fix"
cd ~/fix-dev && sh cluster_bringup/campaign/spike_start_check.sh; echo "exit $?"
echo "=== ALL DONE"
