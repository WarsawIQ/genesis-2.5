#!/bin/bash
# CoreNEURON on the GPU, against the same COBAHH network the CPU arms ran.
#
# The comparison so far is single-threaded CPU on both sides, which is the
# configuration CoreNEURON is least suited to. This runs the one it is built
# for. Same model, same dt, same duration, same node -- only the execution
# target changes.
set -eu
NVHPC_ROOT="$HOME/opt/nvhpc24/Linux_x86_64/24.11"
# make install fails on an RPATH check it cannot satisfy for the substituted
# generators, and re-running it makes nvc++ regenerate sources with the binary
# that segfaults. The build tree is complete, so use it directly.
NRN="$HOME/nrn_src/build-gpu"
export PATH="$NRN/bin:$HOME/opt/miniforge/bin:$NVHPC_ROOT/compilers/bin:$PATH"
export LD_LIBRARY_PATH="$NRN/lib:$NVHPC_ROOT/compilers/lib:$NVHPC_ROOT/cuda/12.6/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$NRN/lib/python:${PYTHONPATH:-}"

D="$HOME/coreneuron_cmp/destexhe_benchmarks/NEURON/cobahh"
cd "$D" || exit 1

echo "=== toolchain ==="
which nrniv nrnivmodl || true
nrniv -c 'print "hoc ok"' 2>&1 | tail -1 || true

# The GPU library has to be built by the GPU-enabled nrnivmodl, not the CPU one.
echo "=== building mechanisms for GPU ==="
rm -rf x86_64_gpu && mkdir -p x86_64_gpu && cd x86_64_gpu
# There is no -gpu flag: offload is compiled into the CoreNEURON library by
# CORENRN_ENABLE_GPU=ON and switched on at run time by coreneuron.gpu.
nrnivmodl -coreneuron ../mechanisms > build_gpu_mech.log 2>&1 \
    || { echo "MECHANISM BUILD FAILED"; grep -iE "error" build_gpu_mech.log | head -15; exit 1; }
ls -la x86_64/libcorenrnmech* 2>/dev/null || ls -la */libcorenrnmech* 2>/dev/null || true
cd "$D"

cat > run_gpu.py <<'EOF'
from neuron import h, coreneuron
h.load_file("stdrun.hoc")
h.cvode.cache_efficient(1)
coreneuron.enable = True
coreneuron.gpu = True
h("mosinit=0")
h.load_file("init.hoc")
EOF

echo "=== running CoreNEURON on GPU ==="
nvidia-smi --query-gpu=name,memory.used --format=csv,noheader
for r in 1 2 3; do
    S=$(date +%s%N)
    timeout 1800 python3 run_gpu.py > "gpu_rep_$r.log" 2>&1
    RC=$?
    E=$(date +%s%N)
    SP=$(wc -l < out.dat 2>/dev/null || echo NA)
    awk "BEGIN{printf \"gpu rep $r wall=%.2f s rc=$RC spikes=$SP\n\", ($E-$S)/1e9}"
    [ "$RC" -eq 0 ] || { echo "--- failure ---"; tail -15 "gpu_rep_$r.log"; break; }
done
