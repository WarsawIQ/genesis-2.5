#!/bin/sh
cd $HOME/vanet2_regression-cpu
for r in 1 2 3; do
  rm -f Vm_out_1000.txt
  S=$(date +%s%N)
  timeout 600 $HOME/genesis-2.5/genesis/src/nxgenesis_nocl -notty -batch VAnet2-batch.g >/dev/null 2>&1
  E=$(date +%s%N)
  awk "BEGIN{printf \"rep$r WALL=%.2f s\n\", ($E-$S)/1e9}"
done
md5sum Vm_out_1000.txt
