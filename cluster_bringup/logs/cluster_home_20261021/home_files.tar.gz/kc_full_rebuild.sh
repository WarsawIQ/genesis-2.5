#!/bin/sh
cd $HOME/genesis-2.5
echo "=== pelna przebudowa (make clean + CPU + CUDA) ==="
sh cluster_bringup/10_build.sh 2>&1 | tail -6
echo "=== EXIT $? ==="
ls -la genesis/src/nxgenesis genesis/src/nxgenesis_nocl 2>/dev/null
