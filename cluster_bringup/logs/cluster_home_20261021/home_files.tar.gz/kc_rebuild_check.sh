#!/bin/sh
sh $HOME/kc_rebuild.sh 2>&1 | tail -3
echo "--- regresja ---"
sh $HOME/genesis-2.5/cluster_bringup/80_accel_regression.sh check 2>&1 | tail -25
