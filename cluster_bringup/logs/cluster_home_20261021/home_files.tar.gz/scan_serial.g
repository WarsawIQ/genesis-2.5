// scan_serial.g — skaner synaps REZERWUARU.
//
// Wypluwa dokladnie format, ktorego oczekuje lsmcd/lesion/parse.py:
//     <pre> <post> <index> <weight>
// po jednej synapsie na linie, komentarze zaczynaja sie od '#'.
//
// PO CO: os synaptic_loss liczy manifest z jednego skanu, a potem drugi
// przebieg zeruje wagi przez `setfield {post} synapse[i].weight 0`. To dziala,
// bo siec jest odtwarzalna - sprawdzone 2026-08-28: trzy niezalezne procesy
// daly identyczne wagi. Domyslne ziarno GENESIS-a jest stale; `randseed <n>`
// przed budowa daje inna siec, ten sam <n> zawsze te sama.
//
// ⚠️ To NIE jest skanuj_synapsy z functions_serial.g. Tamta nalezy do
// pokolenia 25-kolumnowego i zrzuca wagi READOUTU 10x10, ktorego biezacy model
// nie buduje.
//
// Dwie rzeczy, ktorych nie wolno tu zalozyc:
//  1. Kanal moze miec ZERO synaps. Przy in_layer_prob = 0,8 i malej warstwie
//     kanal hamujacy czesto nie dostaje nic (przy 3 wejsciach szansa to 51 %).
//     Czytanie synapse[0] na slepo konczy sie bledem.
//  2. TYLKO synapsy REZERWUAR->REZERWUAR. Kontrakt docs/PIPELINE.md wymaga
//     tego wprost: pelny skan lapie tez siatkowka->rezerwuar (siatkowka wchodzi
//     w dend1/Ex_channel warstwy 1), a wtedy topologia `random` przecinalaby
//     DROGE WEJSCIOWA zamiast uszkadzac rezerwuar. Filtrujemy po prefiksie
//     zrodla, nie po kolejnosci budowy - kolejnosc bylaby cichym zalozeniem.
//  3. Indeks synapsy NIE rowna sie indeksowi wiadomosci. Do kanalu wchodzi tez
//     VOLTAGE z komory (makechannel dodaje ja przy tworzeniu, wiec zwykle jest
//     pierwsza). Liczymy wylacznie wiadomosci typu SPIKE, w ich kolejnosci.

function skanuj_kanal(kanal, plik, net)
    str kanal, plik, net
    int m, n_msg, idx, dl
    str typ, zrodlo

    dl = {strlen {net}}

    n_msg = {getmsg {kanal} -incoming -count}
    idx = 0
    for (m=0; m<{n_msg}; m={m+1})
        typ = {getmsg {kanal} -incoming -type {m}}
        if ({strcmp {typ} "SPIKE"} == 0)
            zrodlo = {getmsg {kanal} -incoming -source {m}}
            // ⚠️ Indeks synapsy liczymy dla KAZDEJ synapsy typu SPIKE, ale
            // zapisujemy tylko te z rezerwuaru. Gdyby idx zwiekszac dopiero po
            // zapisie, indeksy rozjechalyby sie z tymi, ktorych uzywa
            // setfield synapse[i] - a to zerowaloby nie te synapsy.
            if ({strncmp {zrodlo} {net} {dl}} == 0)
                writefile {plik} {zrodlo} {kanal} {idx} \
                          {getfield {kanal} synapse[{idx}].weight}
            end
            idx = {idx + 1}
        end
    end
end

//--------------------------------------------------------------------

function skanuj_rezerwuar(net, plik)
    str net, plik
    int npos, i, j, k

    openfile {plik} w
    writefile {plik} "# pre post index weight"
    writefile {plik} "# skan rezerwuaru," {NodesNumber} "kolumn," \
                     {array_Nx} "x" {array_Ny} "x" {array_Nz}

    for (npos=1; npos<={NodesNumber}; npos={npos+1})
      for (i=1; i<={array_Nx}; i={i+1})
        for (j=1; j<={array_Ny}; j={j+1})
          for (k=1; k<={array_Nz}; k={k+1})
            skanuj_kanal {net}{npos}_{i}_{j}_{k}/dend1/Ex_channel  {plik} {net}
            skanuj_kanal {net}{npos}_{i}_{j}_{k}/dend1/Inh_channel {plik} {net}
            skanuj_kanal {net}{npos}_{i}_{j}_{k}/dend2/Ex_channel  {plik} {net}
            skanuj_kanal {net}{npos}_{i}_{j}_{k}/dend2/Inh_channel {plik} {net}
          end
        end
      end
    end

    closefile {plik}
    echo "skan zapisany do" {plik}
end
