import arbor as A
cat = A.default_catalogue()
for name in ("expsyn", "exp2syn"):
    if name in cat:
        info = cat[name]
        print(name, "-> params:", dict(info.parameters))
