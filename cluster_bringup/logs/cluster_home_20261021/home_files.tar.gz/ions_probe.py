import arbor as A
from arbor import units as U
p = A.neuron_cable_properties()
print("default ion settings from neuron_cable_properties():")
for ion in ("na","k","ca"):
    try:
        print(" ", ion, p.ion_data(ion) if hasattr(p,"ion_data") else "n/a")
    except Exception as e:
        print(" ", ion, "ERR", e)
print("props attrs:", [a for a in dir(p) if "ion" in a])
d = A.decor()
print("decor set_ion doc:")
print(A.decor.set_ion.__doc__)
