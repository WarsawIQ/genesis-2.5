#!/bin/bash
# Drive CoreNEURON on the GPU from hoc.
#
# The Python module built by nvc++ segfaults on `from neuron import h`, the same
# way the code generators did, while nrniv itself runs. CoreNEURON is reachable
# from hoc through ParallelContext.nrncore_run(), so the benchmark can be driven
# without the broken binding. Everything else is unchanged: same model, dt,
# duration and node as the CPU arms.
set -eu
NRN="$HOME/nrn_src/build-gpu"
V="$HOME/opt/nvhpc24/Linux_x86_64/24.11"
export PATH="$NRN/bin:$V/compilers/bin:$PATH"
export LD_LIBRARY_PATH="$NRN/lib:$V/compilers/lib:$V/cuda/12.6/lib64:${LD_LIBRARY_PATH:-}"
export CORENEURONLIB="$HOME/coreneuron_cmp/destexhe_benchmarks/NEURON/cobahh/x86_64_gpu/x86_64/libcorenrnmech.so"

D="$HOME/coreneuron_cmp/destexhe_benchmarks/NEURON/cobahh"
# Work on a copy so the CPU arms measured earlier stay untouched.
TREE="$HOME/destexhe_gpu"
rm -rf "$TREE"
cp -a "$HOME/coreneuron_cmp/destexhe_benchmarks" "$TREE"
cd "$TREE/NEURON/cobahh"

# Route prun() through CoreNEURON instead of NEURON's own solver. tstop is
# already set by common/init.hoc; --gpu selects the offloaded build.
python3 - <<'PY'
import re,io
p="../common/perfrun.hoc"
s=open(p).read()
s=s.replace("\tstdinit()\n\tpnm.psolve(tstop)\n",
            "\tstdinit()\n\tif (name_declared(\"use_coreneuron_gpu\")) {\n\t\tpnm.pc.nrncore_run(\"--gpu\")\n\t} else {\n\t\tpnm.psolve(tstop)\n\t}\n")
open(p,"w").write(s)
print("perfrun patched:", "nrncore_run" in open(p).read())
PY

cp -f "$D/x86_64_gpu/x86_64/libcorenrnmech.so" . 2>/dev/null || true
ln -sfn "$D/x86_64_gpu/x86_64" x86_64 2>/dev/null || true

nvidia-smi --query-gpu=name,memory.used --format=csv,noheader
for r in 1 2 3; do
    S=$(date +%s%N)
    nrniv -c 'use_coreneuron_gpu=1' -c 'mosinit=0' init.hoc > "gpu_hoc_$r.log" 2>&1
    RC=$?
    E=$(date +%s%N)
    SP=$(wc -l < out.dat 2>/dev/null || echo NA)
    awk "BEGIN{printf \"GPU rep $r wall=%.2f s rc=$RC spikes=$SP\n\", ($E-$S)/1e9}"
    grep -iE "RunTime|Solver Time" "gpu_hoc_$r.log" | head -2 || true
    [ "$RC" -eq 0 ] || { echo "--- tail ---"; tail -12 "gpu_hoc_$r.log"; break; }
done
