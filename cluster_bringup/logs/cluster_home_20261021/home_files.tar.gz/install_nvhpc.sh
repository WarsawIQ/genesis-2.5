#!/bin/bash
# Install the NVHPC SDK into $HOME so CoreNEURON can be built with GPU support.
#
# CoreNEURON offloads through OpenACC, which needs NVIDIA's compilers; the CUDA
# toolkit alone is not enough, and the cluster has no nvc++. This installs
# locally, without root. The cuda_12.8 single-CUDA package is chosen to match
# the toolkit GENESIS already builds against (7.9 GB rather than 12.2 GB for
# the multi-CUDA bundle).
set -eu
VER=25.3
PKG=nvhpc_2025_253_Linux_x86_64_cuda_12.8
DEST="$HOME/opt/nvhpc"
WORK="$HOME/nvhpc_dl"

mkdir -p "$WORK" "$DEST"
cd "$WORK"

if [ ! -s "$PKG.tar.gz" ]; then
    echo "downloading $PKG.tar.gz ..."
    curl -sSL --retry 3 -C - -o "$PKG.tar.gz" \
        "https://developer.download.nvidia.com/hpc-sdk/$VER/$PKG.tar.gz"
fi
ls -la "$PKG.tar.gz"

if [ ! -d "$PKG" ]; then
    echo "extracting ..."
    tar xpzf "$PKG.tar.gz"
fi

echo "installing to $DEST ..."
cd "$PKG"
NVHPC_SILENT=true \
NVHPC_INSTALL_DIR="$DEST" \
NVHPC_INSTALL_TYPE=single \
./install

echo "=== result ==="
find "$DEST" -maxdepth 4 -name nvc++ -type f 2>/dev/null | head -3
