#!/bin/sh
# $1=arm(cpu|gpu) $2=binarka $3=opcjonalny K multiloop
A=$1; BIN=$2; K=$3
cd $HOME/vanet2_$A
export LD_LIBRARY_PATH="/storage/opt/cuda/cuda-12.8/lib64:${LD_LIBRARY_PATH:-}"
[ -n "$K" ] && export GENESIS_CUDA_MULTILOOP=$K
echo "=== $A :: $(hostname) :: multiloop=${K:-brak} ==="
S=$(date +%s.%N); timeout 1800 "$BIN" -notty -batch VAnet2-batch.g > out.log 2>&1; RC=$?; E=$(date +%s.%N)
echo "exit=$RC wall=$(echo "$E - $S" | bc)s"
