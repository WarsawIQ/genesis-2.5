import arbor as A
from arbor import units as U
NCOMP=16
tree=A.segment_tree()
p=tree.append(A.mnpos, A.mpoint(0,0,0,10.0), A.mpoint(20,0,0,10.0), tag=1)
x=20.0
for _ in range(NCOMP-1):
    p=tree.append(p, A.mpoint(x,0,0,1.0), A.mpoint(x+50.0,0,0,1.0), tag=2)
    x+=50.0
m=A.morphology(tree)
print("num_branches:", m.num_branches)
for b in range(m.num_branches):
    segs=m.branch_segments(b)
    print(f"  branch {b}: {len(segs)} segments, x from {segs[0].prox.x} to {segs[-1].dist.x}")
lbl=A.label_dict({})
cell=A.cable_cell(m, A.decor(), lbl)
for loc in ["(location 0 0.0)","(location 0 0.5)","(location 0 1.0)","(root)"]:
    try:
        r=cell.locations(loc)
        print(f"{loc:22} -> {r}")
    except Exception as e:
        print(f"{loc:22} -> ERR {e}")
# where does (location 0 0.5) sit in microns?
import math
tot=20.0+ (NCOMP-1)*50.0
print("total cable length (um):", tot, " -> 0.5 along branch 0 =", 0.5*tot, "um from root")
print("soma occupies 0 .. 20 um, i.e. relative 0 ..", 20.0/tot)
